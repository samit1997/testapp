# VaultShare — Enterprise File Management System

> Secure, cloud-native file sharing with TOTP 2FA, per-user folder access, admin approval workflow, and full audit logging.

---

## Architecture

```
Internet → AWS ALB → Nginx → React Frontend (ECS Fargate)
                           → Node.js API  (ECS Fargate)
                                ↓
                          AWS RDS MySQL (Multi-AZ)
                          AWS ElastiCache Redis
                          AWS S3 (AES-256, versioned)
                          AWS SES (email notifications)
```

## Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT (access 8h + refresh 7d, Redis blacklist) |
| 2FA | TOTP (RFC 6238) — Google/Authy/Microsoft Authenticator |
| Passwords | bcrypt (12 rounds) |
| File Storage | S3 SSE-AES256, pre-signed URLs only (never public) |
| Transit | TLS 1.3, HSTS preload |
| Database | RDS Multi-AZ, encrypted at rest, SSL enforced |
| Rate Limiting | express-rate-limit + Nginx |
| Account Lockout | 5 failed attempts → 15-min lockout |
| Audit Log | Every action logged (user, IP, timestamp, resource) |
| File Scanning | Magic-byte checks + ClamAV integration point |
| Headers | Helmet.js (CSP, X-Frame-Options, etc.) |
| Input Sanitization | express-validator + XSS library |

---

## Quick Start (Local Development)

### Prerequisites
- Node.js 20+
- Docker + Docker Compose
- AWS account (for S3 + SES in prod)

### 1. Clone & Configure

```bash
git clone <repo>
cd vaultshare

# Backend config
cp backend/.env.example backend/.env
# Edit backend/.env with your values
```

### 2. Start Services

```bash
# Start MySQL + Redis locally
docker-compose up mysql redis -d

# Install backend deps & run
cd backend
npm install
node src/server.js

# In another terminal, install frontend & run
cd frontend
npm install
npm start
```

### 3. Initialize Database

```bash
# Apply schema
mysql -h localhost -u vaultshare_admin -p vaultshare < backend/src/config/schema.sql

# Create admin user (change password immediately!)
mysql -h localhost -u vaultshare_admin -p vaultshare <<SQL
UPDATE users SET password_hash = '$2b$12$...' WHERE email = 'admin@vaultshare.io';
SQL
```

---

## AWS Deployment

### Prerequisites
- AWS CLI configured
- Terraform >= 1.5
- Docker

### 1. Deploy Infrastructure

```bash
cd infrastructure/terraform
terraform init
terraform plan -var="db_password=STRONG_PASS" -var="redis_password=STRONG_PASS"
terraform apply
```

### 2. Configure SES

```bash
# Verify sender domain in AWS SES console
aws ses verify-domain-identity --domain vaultshare.io --region ap-southeast-1

# Create SMTP credentials in SES console
# Add to backend .env:
# AWS_SES_SMTP_USER=...
# AWS_SES_SMTP_PASSWORD=...
```

### 3. Build & Push Docker Images

```bash
# Backend
docker build -t vaultshare-backend ./backend
docker tag vaultshare-backend <ECR_URI>/vaultshare-backend:latest
docker push <ECR_URI>/vaultshare-backend:latest

# Frontend
docker build -t vaultshare-frontend ./frontend
docker tag vaultshare-frontend <ECR_URI>/vaultshare-frontend:latest
docker push <ECR_URI>/vaultshare-frontend:latest
```

### 4. Deploy to ECS

```bash
# Update ECS service with new image
aws ecs update-service --cluster vaultshare-cluster \
  --service vaultshare-backend --force-new-deployment

aws ecs update-service --cluster vaultshare-cluster \
  --service vaultshare-frontend --force-new-deployment
```

---

## User Workflow

### Registration Flow

```
User fills registration form
  → POST /api/auth/register
  → Email sent to user: "Request received"
  → Email sent to admin: "New request — action required"

Admin reviews in console
  → Assigns folder name (e.g. RMZSG01)
  → Sets quota (e.g. 1 TB) and permissions (RW or RO)
  → Generates temp password
  → POST /api/admin/requests/:id/approve

System creates:
  → Company record
  → User account (status: active)
  → S3 folder (s3://vaultshare-prod/RMZSG01/)
  → Folder permission record
  → Approval email to user with credentials
```

### Login Flow

```
User enters email + password
  → POST /api/auth/login
  → If 2FA enabled: returns { requiresTOTP: true }
User enters 6-digit TOTP
  → POST /api/auth/login (with totpToken)
  → Returns { accessToken, user }
  → Refresh token set as httpOnly cookie
```

### File Upload Flow

```
User selects folder (must have write permission)
  → Drag & drop or click to upload
  → POST /api/folders/:folderId/files/upload (multipart)
  → Server: validates file type, scans, computes SHA-256
  → Uploads to S3: s3://vaultshare-prod/RMZSG01/uuid-filename.pdf
  → Updates folder.used_bytes in MySQL
  → Audit log entry created
```

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Submit registration request |
| POST | `/api/auth/login` | Login (returns TOTP prompt if enabled) |
| POST | `/api/auth/2fa/setup` | Generate TOTP QR code |
| POST | `/api/auth/2fa/verify` | Verify TOTP and enable 2FA |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/logout` | Revoke session |

### User
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/user/folders` | List my shared folders |
| GET | `/api/user/profile` | Get my profile |
| GET | `/api/user/activity` | Get my activity log |

### Files
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/folders/:id/files` | List files in folder |
| POST | `/api/folders/:id/files/upload` | Upload file(s) |
| GET | `/api/files/:id/download` | Get pre-signed download URL |
| DELETE | `/api/files/:id` | Soft-delete file |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/requests` | List registration requests |
| POST | `/api/admin/requests/:id/approve` | Approve + create account |
| POST | `/api/admin/requests/:id/reject` | Reject request |
| GET | `/api/admin/users` | List all users |
| PATCH | `/api/admin/users/:id/permissions` | Update permissions |
| PATCH | `/api/admin/users/:id/status` | Suspend/reinstate |
| GET | `/api/admin/folders` | List all folders |
| POST | `/api/admin/folders` | Create folder |
| GET | `/api/admin/audit-log` | View audit log |
| GET | `/api/admin/storage` | Storage statistics |

---

## Folder Naming Convention

```
{COMPANY_CODE}{CITY_CODE}{SEQUENCE}
Examples:
  RMZ Corp, Singapore → RMZSG01, RMZSG02
  TechCo, Singapore   → TCSG01
  Infra Partners, SG  → IPSG03
```

---

## Environment Variables Reference

See `backend/.env.example` for all required variables.

Critical ones:
- `JWT_SECRET` — minimum 32 random chars
- `JWT_REFRESH_SECRET` — different from JWT_SECRET
- `DB_PASSWORD` — strong MySQL password
- `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` — IAM user with S3 + SES access
- `S3_BUCKET_NAME` — your S3 bucket name
- `SES_FROM_EMAIL` — verified SES sender email

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Query, Zustand, React Router, React Dropzone |
| Backend | Node.js 20, Express 4, Sequelize ORM |
| Database | MySQL 8.0 (AWS RDS Multi-AZ) |
| Cache/Sessions | Redis 7 (AWS ElastiCache) |
| File Storage | AWS S3 (AES-256, versioned, lifecycle policies) |
| Email | AWS SES (SMTP via Nodemailer) |
| 2FA | speakeasy (RFC 6238 TOTP) + QRCode |
| Auth | JWT (HS256) + bcrypt (12 rounds) |
| Infrastructure | AWS ECS Fargate, ALB, VPC, Terraform |
| Proxy | Nginx (TLS 1.3, rate limiting, security headers) |
| Containers | Docker + Docker Compose |
| Logging | Winston (daily rotate) + CloudWatch |
