const { createClient } = require('redis');
const logger = require('../utils/logger');

let client;

const connectRedis = async () => {
  client = createClient({
    socket: {
      host: process.env.REDIS_HOST,
      port: parseInt(process.env.REDIS_PORT) || 6379,
      tls: process.env.NODE_ENV === 'production',
      reconnectStrategy: (retries) => Math.min(retries * 100, 3000),
    },
    password: process.env.REDIS_PASSWORD || undefined,
  });

  client.on('error', (err) => logger.error('Redis error:', err));
  client.on('connect', () => logger.info('Redis connected'));
  client.on('reconnecting', () => logger.warn('Redis reconnecting'));

  await client.connect();
  return client;
};

const getRedis = () => {
  if (!client) throw new Error('Redis not initialized');
  return client;
};

// Token blacklist helpers
const blacklistToken = async (jti, expiresInSeconds) => {
  await getRedis().setEx(`blacklist:${jti}`, expiresInSeconds, '1');
};

const isTokenBlacklisted = async (jti) => {
  const val = await getRedis().get(`blacklist:${jti}`);
  return val === '1';
};

// Session store helpers
const setSession = async (sessionId, data, ttlSeconds) => {
  await getRedis().setEx(`session:${sessionId}`, ttlSeconds, JSON.stringify(data));
};

const getSession = async (sessionId) => {
  const data = await getRedis().get(`session:${sessionId}`);
  return data ? JSON.parse(data) : null;
};

const deleteSession = async (sessionId) => {
  await getRedis().del(`session:${sessionId}`);
};

// Rate limit helpers (used as fallback)
const incrWithExpiry = async (key, windowSecs) => {
  const multi = getRedis().multi();
  multi.incr(key);
  multi.expire(key, windowSecs);
  const results = await multi.exec();
  return results[0];
};

module.exports = {
  connectRedis,
  getRedis,
  blacklistToken,
  isTokenBlacklisted,
  setSession,
  getSession,
  deleteSession,
  incrWithExpiry,
};
