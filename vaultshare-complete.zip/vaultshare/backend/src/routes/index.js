const express = require('express');
const rateLimit = require('express-rate-limit');
const { body } = require('express-validator');

const authCtrl = require('../controllers/authController');
const adminCtrl = require('../controllers/adminController');
const fileCtrl = require('../controllers/fileController');
const { authenticate, requireAdmin, require2FA, checkFolderPermission, auditLog } = require('../middleware/auth');
const { upload, validateUpload, handleMulterError } = require('../middleware/upload');

const router = express.Router();

// ── Rate Limiters ─────────────────────────────────────────────

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  message: { error: 'Too many auth attempts. Try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 900000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 200,
  message: { error: 'Rate limit exceeded' },
});

const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 50,
  message: { error: 'Upload rate limit exceeded. Max 50 uploads per hour.' },
});

// ── Health Check ──────────────────────────────────────────────
router.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// ── Auth Routes ───────────────────────────────────────────────
router.post('/auth/register',     authLimiter, authCtrl.registerValidation, authCtrl.register);
router.post('/auth/login',        authLimiter, authCtrl.loginValidation, authCtrl.login);
router.post('/auth/refresh',      authLimiter, authCtrl.refreshToken);
router.post('/auth/logout',       authenticate, authCtrl.logout);

// 2FA
router.post('/auth/2fa/setup',    authenticate, authCtrl.setup2FA);
router.post('/auth/2fa/verify',   authenticate, [body('token').isLength({ min: 6, max: 6 }).isNumeric()], authCtrl.verify2FA);

// ── User Routes ───────────────────────────────────────────────

// Get my folders
router.get('/user/folders', apiLimiter, authenticate, require2FA, async (req, res) => {
  const { sequelize } = require('../config/database');
  try {
    const [folders] = await sequelize.query(
      `SELECT sf.id, sf.folder_name, sf.description, sf.quota_bytes, sf.used_bytes,
              sf.is_active, sf.created_at, fp.permission,
              c.name AS company_name
       FROM folder_permissions fp
       JOIN shared_folders sf ON sf.id = fp.folder_id
       LEFT JOIN companies c ON c.id = sf.company_id
       WHERE fp.user_id = ? AND sf.is_active = 1
       AND fp.permission != 'none'
       AND (fp.expires_at IS NULL OR fp.expires_at > NOW())`,
      { replacements: [req.user.id] }
    );
    return res.json({ folders });
  } catch (err) { return res.status(500).json({ error: 'Failed to fetch folders' }); }
});

// Get my profile
router.get('/user/profile', apiLimiter, authenticate, async (req, res) => {
  const { sequelize } = require('../config/database');
  const [users] = await sequelize.query(
    `SELECT u.id, u.email, u.full_name, u.mobile, u.totp_enabled, u.last_login_at,
            u.last_login_ip, u.created_at, c.name AS company_name, c.location
     FROM users u LEFT JOIN companies c ON c.id = u.company_id
     WHERE u.id = ? LIMIT 1`,
    { replacements: [req.user.id] }
  );
  return res.json({ user: users[0] });
});

// Get my activity
router.get('/user/activity', apiLimiter, authenticate, async (req, res) => {
  const { sequelize } = require('../config/database');
  const [logs] = await sequelize.query(
    `SELECT action, resource_type, resource_name, ip_address, status, created_at
     FROM audit_log WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`,
    { replacements: [req.user.id] }
  );
  return res.json({ activity: logs });
});

// ── File Routes ───────────────────────────────────────────────

// List files in folder
router.get('/folders/:folderId/files',
  apiLimiter, authenticate, require2FA,
  checkFolderPermission('read'),
  fileCtrl.listFiles
);

// Get presigned upload URL
router.get('/folders/:folderId/presigned-upload',
  apiLimiter, authenticate, require2FA,
  checkFolderPermission('write'),
  fileCtrl.getUploadUrl
);

// Upload file (server-side multipart)
router.post('/folders/:folderId/files/upload',
  uploadLimiter, authenticate, require2FA,
  checkFolderPermission('write'),
  upload.array('files', 10),
  handleMulterError,
  validateUpload,
  auditLog('FILE_UPLOAD', 'file'),
  fileCtrl.uploadFile
);

// Download file (get presigned URL)
router.get('/files/:fileId/download',
  apiLimiter, authenticate, require2FA,
  fileCtrl.downloadFile
);

// Delete file
router.delete('/files/:fileId',
  apiLimiter, authenticate, require2FA,
  checkFolderPermission('write'),
  fileCtrl.deleteFile
);

// ── Admin Routes ──────────────────────────────────────────────

// Registration requests
router.get('/admin/requests',           authenticate, requireAdmin, adminCtrl.getRegistrationRequests);
router.post('/admin/requests/:requestId/approve', authenticate, requireAdmin, adminCtrl.approveRequest);
router.post('/admin/requests/:requestId/reject',  authenticate, requireAdmin, adminCtrl.rejectRequest);

// User management
router.get('/admin/users',                        authenticate, requireAdmin, adminCtrl.getUsers);
router.patch('/admin/users/:userId/permissions',  authenticate, requireAdmin, adminCtrl.updateUserPermissions);
router.patch('/admin/users/:userId/status',       authenticate, requireAdmin, adminCtrl.suspendUser);

// Folder management
router.get('/admin/folders',                      authenticate, requireAdmin, adminCtrl.getFolders);
router.post('/admin/folders',                     authenticate, requireAdmin, adminCtrl.createFolder);
router.delete('/admin/folders/:folderId',         authenticate, requireAdmin, adminCtrl.deleteFolder);

// Audit log
router.get('/admin/audit-log',                    authenticate, requireAdmin, adminCtrl.getAuditLog);

// Storage stats
router.get('/admin/storage',                      authenticate, requireAdmin, adminCtrl.getStorageStats);

module.exports = router;
