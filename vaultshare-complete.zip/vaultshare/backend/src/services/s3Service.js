const {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
  ListObjectsV2Command,
} = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { Upload } = require('@aws-sdk/lib-storage');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const logger = require('../utils/logger');

const s3 = new S3Client({
  region: process.env.AWS_REGION || 'ap-southeast-1',
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const BUCKET = process.env.S3_BUCKET_NAME;
const URL_EXPIRY = parseInt(process.env.S3_PRESIGNED_URL_EXPIRY) || 3600;

/**
 * Build S3 key: folderName/uuid-filename
 */
const buildS3Key = (folderName, originalName) => {
  const ext = originalName.split('.').pop()?.toLowerCase() || 'bin';
  const safeName = originalName.replace(/[^a-zA-Z0-9._-]/g, '_');
  return `${folderName}/${uuidv4()}-${safeName}`;
};

/**
 * Upload a file stream to S3 with multipart support
 */
const uploadFileToS3 = async ({ stream, folderName, originalName, mimeType, userId }) => {
  const s3Key = buildS3Key(folderName, originalName);

  const upload = new Upload({
    client: s3,
    params: {
      Bucket: BUCKET,
      Key: s3Key,
      Body: stream,
      ContentType: mimeType || 'application/octet-stream',
      ServerSideEncryption: 'AES256',
      Metadata: {
        'uploaded-by': userId,
        'original-name': encodeURIComponent(originalName),
        'folder': folderName,
      },
    },
    queueSize: 4,
    partSize: 1024 * 1024 * 10, // 10 MB parts
    leavePartsOnError: false,
  });

  upload.on('httpUploadProgress', (progress) => {
    logger.debug(`S3 upload progress: ${JSON.stringify(progress)}`);
  });

  const result = await upload.done();
  logger.info(`File uploaded to S3: ${s3Key}`);
  return { s3Key, location: result.Location };
};

/**
 * Generate a pre-signed download URL (time-limited, no public access)
 */
const getPresignedDownloadUrl = async (s3Key, filename) => {
  const command = new GetObjectCommand({
    Bucket: BUCKET,
    Key: s3Key,
    ResponseContentDisposition: `attachment; filename="${encodeURIComponent(filename)}"`,
  });
  const url = await getSignedUrl(s3, command, { expiresIn: URL_EXPIRY });
  return url;
};

/**
 * Generate a pre-signed upload URL (for direct browser uploads)
 */
const getPresignedUploadUrl = async (folderName, originalName, mimeType) => {
  const s3Key = buildS3Key(folderName, originalName);
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: s3Key,
    ContentType: mimeType,
    ServerSideEncryption: 'AES256',
  });
  const url = await getSignedUrl(s3, command, { expiresIn: 300 }); // 5 min to start upload
  return { url, s3Key };
};

/**
 * Soft-delete on S3 (move to _deleted/ prefix, not permanent)
 */
const markFileDeletedOnS3 = async (s3Key) => {
  // In production: use S3 lifecycle rules to auto-expire _deleted/ after 30 days
  logger.info(`File marked for deletion: ${s3Key}`);
  // Actual deletion handled by lifecycle policy or scheduled job
};

/**
 * Permanently delete from S3
 */
const deleteFileFromS3 = async (s3Key) => {
  const command = new DeleteObjectCommand({ Bucket: BUCKET, Key: s3Key });
  await s3.send(command);
  logger.info(`File permanently deleted from S3: ${s3Key}`);
};

/**
 * Get file metadata from S3
 */
const getFileMetadata = async (s3Key) => {
  const command = new HeadObjectCommand({ Bucket: BUCKET, Key: s3Key });
  const meta = await s3.send(command);
  return {
    size: meta.ContentLength,
    lastModified: meta.LastModified,
    contentType: meta.ContentType,
    serverSideEncryption: meta.ServerSideEncryption,
  };
};

/**
 * List objects in a folder prefix
 */
const listFolderContents = async (folderName, maxKeys = 1000) => {
  const command = new ListObjectsV2Command({
    Bucket: BUCKET,
    Prefix: `${folderName}/`,
    MaxKeys: maxKeys,
  });
  const result = await s3.send(command);
  return result.Contents || [];
};

/**
 * Calculate SHA-256 checksum of a buffer
 */
const calculateChecksum = (buffer) => {
  return crypto.createHash('sha256').update(buffer).digest('hex');
};

module.exports = {
  uploadFileToS3,
  getPresignedDownloadUrl,
  getPresignedUploadUrl,
  markFileDeletedOnS3,
  deleteFileFromS3,
  getFileMetadata,
  listFolderContents,
  buildS3Key,
  calculateChecksum,
};
