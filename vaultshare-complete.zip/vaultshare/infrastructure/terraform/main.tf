# ============================================================
# VaultShare - AWS Infrastructure (Terraform)
# Region: ap-southeast-1 (Singapore)
# ============================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
  backend "s3" {
    bucket = "vaultshare-terraform-state"
    key    = "prod/terraform.tfstate"
    region = "ap-southeast-1"
    encrypt = true
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = { Project = "VaultShare", Environment = var.environment, ManagedBy = "Terraform" }
  }
}

variable "aws_region"   { default = "ap-southeast-1" }
variable "environment"  { default = "production" }
variable "db_password"  { sensitive = true }
variable "redis_password" { sensitive = true }

# ── VPC ──────────────────────────────────────────────────────
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags = { Name = "vaultshare-vpc" }
}

resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "vaultshare-igw" }
}

# Public subnets (for ALB, NAT)
resource "aws_subnet" "public" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags = { Name = "vaultshare-public-${count.index + 1}" }
}

# Private subnets (for EC2, RDS, Redis)
resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index + 10}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags = { Name = "vaultshare-private-${count.index + 1}" }
}

data "aws_availability_zones" "available" { state = "available" }

# ── NAT Gateway ───────────────────────────────────────────────
resource "aws_eip" "nat" { domain = "vpc" }
resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.public[0].id
  tags = { Name = "vaultshare-nat" }
}

# Route tables
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route { cidr_block = "0.0.0.0/0"; gateway_id = aws_internet_gateway.igw.id }
  tags = { Name = "vaultshare-public-rt" }
}
resource "aws_route_table_association" "public" {
  count          = 2
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id
  route { cidr_block = "0.0.0.0/0"; nat_gateway_id = aws_nat_gateway.nat.id }
  tags = { Name = "vaultshare-private-rt" }
}
resource "aws_route_table_association" "private" {
  count          = 2
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}

# ── Security Groups ───────────────────────────────────────────
resource "aws_security_group" "alb" {
  name   = "vaultshare-alb-sg"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 80;  to_port = 80;  protocol = "tcp"; cidr_blocks = ["0.0.0.0/0"] }
  ingress { from_port = 443; to_port = 443; protocol = "tcp"; cidr_blocks = ["0.0.0.0/0"] }
  egress  { from_port = 0;   to_port = 0;   protocol = "-1";  cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "app" {
  name   = "vaultshare-app-sg"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 5000; to_port = 5000; protocol = "tcp"; security_groups = [aws_security_group.alb.id] }
  egress  { from_port = 0;    to_port = 0;    protocol = "-1";  cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "rds" {
  name   = "vaultshare-rds-sg"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 3306; to_port = 3306; protocol = "tcp"; security_groups = [aws_security_group.app.id] }
}

resource "aws_security_group" "redis" {
  name   = "vaultshare-redis-sg"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 6379; to_port = 6379; protocol = "tcp"; security_groups = [aws_security_group.app.id] }
}

# ── S3 Bucket ─────────────────────────────────────────────────
resource "aws_s3_bucket" "storage" {
  bucket        = "vaultshare-prod-sg"
  force_destroy = false
}

resource "aws_s3_bucket_versioning" "storage" {
  bucket = aws_s3_bucket.storage.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "storage" {
  bucket = aws_s3_bucket.storage.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "storage" {
  bucket                  = aws_s3_bucket.storage.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_logging" "storage" {
  bucket        = aws_s3_bucket.storage.id
  target_bucket = aws_s3_bucket.storage.id
  target_prefix = "_access-logs/"
}

resource "aws_s3_bucket_lifecycle_configuration" "storage" {
  bucket = aws_s3_bucket.storage.id
  rule {
    id     = "archive-old-versions"
    status = "Enabled"
    filter { prefix = "" }
    noncurrent_version_transition {
      noncurrent_days = 30
      storage_class   = "STANDARD_IA"
    }
    noncurrent_version_transition {
      noncurrent_days = 90
      storage_class   = "GLACIER"
    }
    noncurrent_version_expiration { noncurrent_days = 365 }
  }
  rule {
    id     = "expire-deleted"
    status = "Enabled"
    filter { prefix = "_deleted/" }
    expiration { days = 30 }
  }
}

# ── RDS MySQL ─────────────────────────────────────────────────
resource "aws_db_subnet_group" "main" {
  name       = "vaultshare-db-subnet"
  subnet_ids = aws_subnet.private[*].id
}

resource "aws_db_instance" "mysql" {
  identifier             = "vaultshare-mysql"
  engine                 = "mysql"
  engine_version         = "8.0"
  instance_class         = "db.r6g.large"
  allocated_storage      = 100
  max_allocated_storage  = 1000
  storage_type           = "gp3"
  storage_encrypted      = true
  db_name                = "vaultshare"
  username               = "vaultshare_admin"
  password               = var.db_password
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]
  multi_az               = true
  backup_retention_period = 35
  backup_window          = "02:00-04:00"
  maintenance_window     = "sun:04:00-sun:06:00"
  deletion_protection    = true
  skip_final_snapshot    = false
  final_snapshot_identifier = "vaultshare-final-${formatdate("YYYY-MM-DD", timestamp())}"
  performance_insights_enabled = true
  enabled_cloudwatch_logs_exports = ["error", "general", "slowquery", "audit"]
  tags = { Name = "vaultshare-mysql" }
}

# ── ElastiCache Redis ─────────────────────────────────────────
resource "aws_elasticache_subnet_group" "redis" {
  name       = "vaultshare-redis-subnet"
  subnet_ids = aws_subnet.private[*].id
}

resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "vaultshare-redis"
  description                = "VaultShare Redis session store"
  node_type                  = "cache.r7g.large"
  num_cache_clusters         = 2
  parameter_group_name       = "default.redis7"
  port                       = 6379
  subnet_group_name          = aws_elasticache_subnet_group.redis.name
  security_group_ids         = [aws_security_group.redis.id]
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  auth_token                 = var.redis_password
  automatic_failover_enabled = true
  tags = { Name = "vaultshare-redis" }
}

# ── ECS Fargate (App) ─────────────────────────────────────────
resource "aws_ecs_cluster" "main" {
  name = "vaultshare-cluster"
  setting { name = "containerInsights"; value = "enabled" }
}

# ── ALB ──────────────────────────────────────────────────────
resource "aws_lb" "main" {
  name               = "vaultshare-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id
  enable_deletion_protection = true
  tags = { Name = "vaultshare-alb" }
}

# ── CloudWatch Alarms ─────────────────────────────────────────
resource "aws_cloudwatch_metric_alarm" "rds_cpu" {
  alarm_name          = "vaultshare-rds-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/RDS"
  period              = 300
  statistic           = "Average"
  threshold           = 80
  alarm_description   = "RDS CPU > 80%"
  dimensions = { DBInstanceIdentifier = aws_db_instance.mysql.identifier }
}

# ── Outputs ───────────────────────────────────────────────────
output "s3_bucket"      { value = aws_s3_bucket.storage.bucket }
output "rds_endpoint"   { value = aws_db_instance.mysql.endpoint }
output "redis_endpoint" { value = aws_elasticache_replication_group.redis.primary_endpoint_address }
output "alb_dns"        { value = aws_lb.main.dns_name }
