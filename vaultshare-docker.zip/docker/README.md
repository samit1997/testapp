# VaultShare — Docker Deployment Guide

## Folder Structure
Place these docker files inside your project like this:

```
vaultshare/
├── backend/              ← your existing backend
├── frontend/             ← your existing frontend
└── docker/               ← THIS FOLDER (copy here)
    ├── docker-compose.yml
    ├── .env.example
    ├── deploy.sh
    ├── backend/
    │   ├── Dockerfile
    │   └── .dockerignore
    └── frontend/
        ├── Dockerfile
        ├── nginx.conf
        └── .dockerignore
```

---

## 🚀 New EC2 Deploy (One Time Setup)

### Step 1: Launch EC2
- Ubuntu 24.04 LTS
- t2.micro or larger
- Open ports: **22, 80, 443** in Security Group

### Step 2: SSH in and run deploy script
```bash
ssh -i your-key.pem ubuntu@YOUR_EC2_IP

# Upload files or clone from GitHub
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git testapp
cd testapp/vaultshare/docker

# Run deploy script
chmod +x deploy.sh
./deploy.sh
```

### Step 3: Done!
Visit `http://YOUR_EC2_IP`

**Default Admin:**
- Email: `admin@vaultshare.io`
- Password: `Admin@123456`

---

## 🐳 Manual Docker Commands

```bash
cd vaultshare/docker

# Copy and edit environment
cp .env.example .env
nano .env   # set FRONTEND_URL=http://YOUR_EC2_IP

# Build and start all containers
docker compose up -d --build

# View logs
docker compose logs -f

# View specific service logs
docker compose logs -f backend
docker compose logs -f mysql

# Stop everything
docker compose down

# Stop and delete all data (full reset)
docker compose down -v
```

---

## 🔄 Update App (After Code Changes)

```bash
cd vaultshare/docker

# Pull latest code
git pull

# Rebuild and restart
docker compose up -d --build
```

---

## 🗄️ Database Access

```bash
# Connect to MySQL inside container
docker exec -it vaultshare-mysql mysql -u vaultshare_admin -pAdmin1234 vaultshare

# Backup database
docker exec vaultshare-mysql mysqldump -u vaultshare_admin -pAdmin1234 vaultshare > backup.sql

# Restore database
docker exec -i vaultshare-mysql mysql -u vaultshare_admin -pAdmin1234 vaultshare < backup.sql
```

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| Port 80 in use | `sudo systemctl stop nginx` |
| Container won't start | `docker compose logs backend` |
| DB connection error | `docker compose restart mysql` then wait 30s |
| Permission denied | `sudo usermod -aG docker $USER` then re-login |
