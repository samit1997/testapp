#!/bin/bash
set -e

echo "======================================"
echo "  VaultShare - EC2 Deploy Script"
echo "======================================"

# ─── 1. Install Docker ────────────────────────────────────────
echo "[1/5] Installing Docker..."
sudo apt-get update -y
sudo apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update -y
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo usermod -aG docker $USER

echo "[2/5] Docker installed ✓"

# ─── 2. Clone repo ────────────────────────────────────────────
echo "[3/5] Cloning repository..."
cd /home/ubuntu
git clone https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME.git testapp
cd testapp/vaultshare

echo "[4/5] Setting up environment..."
cp docker/.env.example docker/.env

# Set EC2 public IP automatically
EC2_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
sed -i "s/YOUR_EC2_IP_HERE/$EC2_IP/" docker/.env
echo "  EC2 IP detected: $EC2_IP"

# ─── 3. Build and start ───────────────────────────────────────
echo "[5/5] Building and starting containers..."
cd docker
sudo docker compose up -d --build

echo ""
echo "======================================"
echo "  Deploy Complete!"
echo "======================================"
echo "  App URL: http://$EC2_IP"
echo ""
echo "  Default Admin Login:"
echo "  Email:    admin@vaultshare.io"
echo "  Password: Admin@123456"
echo ""
echo "  View logs: docker compose logs -f"
echo "======================================"
