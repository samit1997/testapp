# VaultShare — Enterprise File Management System

> Secure file sharing with TOTP 2FA, per-user folder access, admin approval workflow, and full audit logging.

## Quick Install (Ubuntu 24 EC2 — One Command)

```bash
git clone https://github.com/samit1997/testapp.git vaultshare
cd vaultshare
bash install.sh
```

Answer 3 questions (MySQL password, Redis password, server IP) — everything else is automatic.

## What Gets Installed

| Service | Purpose | Runs on |
|---|---|---|
| Node.js 20 + Express | Backend API | Port 5000 (internal) |
| MySQL 8.0 | Database | Port 3306 (local only) |
| Redis 7 | Sessions & rate limiting | Port 6379 (local only) |
| Nginx | Web server & reverse proxy | Port 80 |
| Mailpit | Local email inbox (no AWS SES) | Port 8025 |
| PM2 | Process manager (auto-restart) | — |

## After Install

| URL | What |
|---|---|
| `http://YOUR_IP` | VaultShare app |
| `http://YOUR_IP:8025` | Mailpit — see all system emails |

**Admin login:** `admin@vaultshare.io` / `Admin@123456`

> ⚠️ Change the admin password immediately after first login.

## EC2 Security Group — Open These Ports

| Port | Purpose |
|---|---|
| 22 | SSH |
| 80 | Web app |
| 8025 | Mailpit email viewer |

## Useful Commands

```bash
pm2 status                          # check backend status
pm2 logs vaultshare-backend         # view live logs
pm2 restart vaultshare-backend      # restart backend
sudo systemctl restart nginx        # restart nginx
sudo systemctl restart mysql        # restart mysql
sudo systemctl restart redis-server # restart redis
```

## Architecture

```
Browser → Nginx (port 80)
              ├── /          → React frontend (static files)
              └── /api/      → Node.js backend (port 5000)
                                  ├── MySQL 8  (database)
                                  ├── Redis 7  (sessions)
                                  ├── Mailpit  (email)
                                  └── /var/www/vaultshare/uploads (files)
```

## Files Changed from Original

| File | Change |
|---|---|
| `backend/src/services/s3Service.js` | Replaced AWS S3 with local disk storage |
| `backend/src/services/emailService.js` | Replaced AWS SES with Mailpit SMTP |
| `backend/src/config/redis.js` | Disabled TLS (not needed locally) |
| `backend/src/server.js` | Removed S3 bucket CSP reference |
| `backend/src/routes/index.js` | Added `/files/serve` local download endpoint |
| `backend/src/config/schema.sql` | Fixed VARCHAR sizes (MySQL key too long error) |
| `backend/package.json` | Added cookie-parser, removed AWS SDKs |
| `frontend/src/pages/*.jsx` | Fixed import paths (`../../` → `../`) |
| `frontend/public/index.html` | Created (was missing from original zip) |
| `frontend/public/manifest.json` | Created (was missing from original zip) |
| `install.sh` | One-click install script |
