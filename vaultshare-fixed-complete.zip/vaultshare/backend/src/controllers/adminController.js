const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { sequelize } = require('../config/database');
const { sendEmail } = require('../services/emailService');
const logger = require('../utils/logger');

const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS) || 12;

// ── Registration Requests ─────────────────────────────────────

const getRegistrationRequests = async (req, res) => {
  try {
    const { status = 'pending', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const [requests] = await sequelize.query(
      `SELECT r.*, u.email AS reviewed_by_email
       FROM registration_requests r
       LEFT JOIN users u ON u.id = r.reviewed_by
       WHERE r.status = ?
       ORDER BY r.created_at DESC
       LIMIT ? OFFSET ?`,
      { replacements: [status, parseInt(limit), parseInt(offset)] }
    );

    const [[{ total }]] = await sequelize.query(
      `SELECT COUNT(*) AS total FROM registration_requests WHERE status = ?`,
      { replacements: [status] }
    );

    return res.json({ requests, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    logger.error('Get requests error:', err);
    return res.status(500).json({ error: 'Failed to fetch requests' });
  }
};

const approveRequest = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { requestId } = req.params;
    const { folderName, quota = '1TB', permissions = 'read', tempPassword } = req.body;

    if (!folderName || !tempPassword) {
      return res.status(400).json({ error: 'folderName and tempPassword required' });
    }

    // Get request
    const [requests] = await sequelize.query(
      `SELECT * FROM registration_requests WHERE id = ? AND status = 'pending' LIMIT 1`,
      { replacements: [requestId], transaction: t }
    );
    if (!requests.length) {
      await t.rollback();
      return res.status(404).json({ error: 'Request not found or already processed' });
    }
    const request = requests[0];

    // Check folder name uniqueness
    const [existingFolder] = await sequelize.query(
      `SELECT id FROM shared_folders WHERE folder_name = ? LIMIT 1`,
      { replacements: [folderName], transaction: t }
    );
    if (existingFolder.length) {
      await t.rollback();
      return res.status(409).json({ error: 'Folder name already exists' });
    }

    // Create or find company
    let companyId = uuidv4();
    const [existingCompany] = await sequelize.query(
      `SELECT id FROM companies WHERE name = ? LIMIT 1`,
      { replacements: [request.company_name], transaction: t }
    );
    if (existingCompany.length) {
      companyId = existingCompany[0].id;
    } else {
      await sequelize.query(
        `INSERT INTO companies (id, name, location, industry) VALUES (?, ?, ?, ?)`,
        { replacements: [companyId, request.company_name, request.company_location, request.industry], transaction: t }
      );
    }

    // Create user account
    const userId = uuidv4();
    const passwordHash = await bcrypt.hash(tempPassword, BCRYPT_ROUNDS);
    await sequelize.query(
      `INSERT INTO users (id, email, full_name, mobile, password_hash, company_id, role, status, email_verified)
       VALUES (?, ?, ?, ?, ?, ?, 'user', 'active', 1)`,
      { replacements: [userId, request.email, request.full_name, request.mobile, passwordHash, companyId], transaction: t }
    );

    // Parse quota to bytes
    const quotaBytes = parseQuota(quota);

    // Create shared folder
    const folderId = uuidv4();
    await sequelize.query(
      `INSERT INTO shared_folders (id, folder_name, s3_prefix, company_id, quota_bytes, created_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      { replacements: [folderId, folderName, `${folderName}/`, companyId, quotaBytes, req.user.id], transaction: t }
    );

    // Assign folder permission
    const permLevel = permissions === 'write' ? 'write' : 'read';
    await sequelize.query(
      `INSERT INTO folder_permissions (id, user_id, folder_id, permission, granted_by)
       VALUES (?, ?, ?, ?, ?)`,
      { replacements: [uuidv4(), userId, folderId, permLevel, req.user.id], transaction: t }
    );

    // Mark request as approved
    await sequelize.query(
      `UPDATE registration_requests SET status = 'approved', reviewed_by = ?, reviewed_at = NOW() WHERE id = ?`,
      { replacements: [req.user.id, requestId], transaction: t }
    );

    await t.commit();

    // Send approval email
    await sendEmail(request.email, 'accountApproved', {
      fullName: request.full_name,
      email: request.email,
      folderName,
      permissions: permLevel,
      quota,
      tempPassword,
    });

    logger.info(`Request approved: ${request.email} → ${folderName} (${permLevel})`);
    return res.json({ message: 'User approved and notified', userId, folderId });
  } catch (err) {
    await t.rollback();
    logger.error('Approve request error:', err);
    return res.status(500).json({ error: 'Approval failed' });
  }
};

const rejectRequest = async (req, res) => {
  try {
    const { requestId } = req.params;
    const { reason } = req.body;

    const [requests] = await sequelize.query(
      `SELECT * FROM registration_requests WHERE id = ? AND status = 'pending' LIMIT 1`,
      { replacements: [requestId] }
    );
    if (!requests.length) return res.status(404).json({ error: 'Request not found' });

    await sequelize.query(
      `UPDATE registration_requests SET status = 'rejected', reviewed_by = ?, reviewed_at = NOW(), rejection_reason = ? WHERE id = ?`,
      { replacements: [req.user.id, reason || null, requestId] }
    );

    await sendEmail(requests[0].email, 'accountRejected', {
      fullName: requests[0].full_name,
      reason,
    });

    return res.json({ message: 'Request rejected' });
  } catch (err) {
    logger.error('Reject request error:', err);
    return res.status(500).json({ error: 'Rejection failed' });
  }
};

// ── User Management ───────────────────────────────────────────

const getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 50, status, search } = req.query;
    const offset = (page - 1) * limit;

    let where = '1=1';
    const replacements = [];

    if (status) { where += ' AND u.status = ?'; replacements.push(status); }
    if (search) { where += ' AND (u.email LIKE ? OR u.full_name LIKE ?)'; replacements.push(`%${search}%`, `%${search}%`); }

    const [users] = await sequelize.query(
      `SELECT u.id, u.email, u.full_name, u.mobile, u.role, u.status, u.totp_enabled,
              u.last_login_at, u.last_login_ip, u.created_at,
              c.name AS company_name, c.location AS company_location,
              GROUP_CONCAT(CONCAT(sf.folder_name, ':', fp.permission) SEPARATOR ',') AS folder_access
       FROM users u
       LEFT JOIN companies c ON c.id = u.company_id
       LEFT JOIN folder_permissions fp ON fp.user_id = u.id
       LEFT JOIN shared_folders sf ON sf.id = fp.folder_id
       WHERE ${where}
       GROUP BY u.id
       ORDER BY u.created_at DESC
       LIMIT ? OFFSET ?`,
      { replacements: [...replacements, parseInt(limit), parseInt(offset)] }
    );

    return res.json({ users });
  } catch (err) {
    logger.error('Get users error:', err);
    return res.status(500).json({ error: 'Failed to fetch users' });
  }
};

const updateUserPermissions = async (req, res) => {
  try {
    const { userId } = req.params;
    const { folderId, permission, status, quota } = req.body;

    if (status) {
      await sequelize.query(
        `UPDATE users SET status = ? WHERE id = ? AND role != 'admin'`,
        { replacements: [status, userId] }
      );
    }

    if (folderId && permission) {
      await sequelize.query(
        `INSERT INTO folder_permissions (id, user_id, folder_id, permission, granted_by)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE permission = ?, granted_by = ?, granted_at = NOW()`,
        { replacements: [uuidv4(), userId, folderId, permission, req.user.id, permission, req.user.id] }
      );
    }

    if (folderId && quota) {
      const quotaBytes = parseQuota(quota);
      await sequelize.query(
        `UPDATE shared_folders SET quota_bytes = ? WHERE id = ?`,
        { replacements: [quotaBytes, folderId] }
      );
    }

    logger.info(`Permissions updated: user=${userId} by admin=${req.user.email}`);
    return res.json({ message: 'Permissions updated' });
  } catch (err) {
    logger.error('Update permissions error:', err);
    return res.status(500).json({ error: 'Failed to update permissions' });
  }
};

const suspendUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const { action } = req.body; // 'suspend' | 'reinstate'

    const newStatus = action === 'reinstate' ? 'active' : 'suspended';
    await sequelize.query(
      `UPDATE users SET status = ? WHERE id = ? AND role != 'admin'`,
      { replacements: [newStatus, userId] }
    );

    logger.info(`User ${action}d: ${userId} by ${req.user.email}`);
    return res.json({ message: `User ${newStatus}` });
  } catch (err) {
    logger.error('Suspend user error:', err);
    return res.status(500).json({ error: 'Failed to update user status' });
  }
};

// ── Folder Management ─────────────────────────────────────────

const getFolders = async (req, res) => {
  try {
    const [folders] = await sequelize.query(
      `SELECT sf.*, c.name AS company_name,
              COUNT(DISTINCT fp.user_id) AS user_count,
              u.email AS created_by_email
       FROM shared_folders sf
       LEFT JOIN companies c ON c.id = sf.company_id
       LEFT JOIN folder_permissions fp ON fp.folder_id = sf.id AND fp.permission != 'none'
       LEFT JOIN users u ON u.id = sf.created_by
       GROUP BY sf.id
       ORDER BY sf.created_at DESC`
    );
    return res.json({ folders });
  } catch (err) {
    logger.error('Get folders error:', err);
    return res.status(500).json({ error: 'Failed to fetch folders' });
  }
};

const createFolder = async (req, res) => {
  try {
    const { folderName, companyId, quota = '1TB', description } = req.body;
    if (!folderName) return res.status(400).json({ error: 'folderName required' });

    const [existing] = await sequelize.query(
      `SELECT id FROM shared_folders WHERE folder_name = ? LIMIT 1`,
      { replacements: [folderName] }
    );
    if (existing.length) return res.status(409).json({ error: 'Folder name already exists' });

    const folderId = uuidv4();
    const quotaBytes = parseQuota(quota);
    await sequelize.query(
      `INSERT INTO shared_folders (id, folder_name, s3_prefix, company_id, quota_bytes, description, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      { replacements: [folderId, folderName, `${folderName}/`, companyId || null, quotaBytes, description || null, req.user.id] }
    );

    logger.info(`Folder created: ${folderName} by ${req.user.email}`);
    return res.status(201).json({ message: 'Folder created', folderId, folderName });
  } catch (err) {
    logger.error('Create folder error:', err);
    return res.status(500).json({ error: 'Failed to create folder' });
  }
};

const deleteFolder = async (req, res) => {
  try {
    const { folderId } = req.params;
    // Soft delete
    await sequelize.query(
      `UPDATE shared_folders SET is_active = 0 WHERE id = ?`,
      { replacements: [folderId] }
    );
    logger.info(`Folder deactivated: ${folderId} by ${req.user.email}`);
    return res.json({ message: 'Folder deactivated' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete folder' });
  }
};

// ── Audit Log ─────────────────────────────────────────────────

const getAuditLog = async (req, res) => {
  try {
    const { page = 1, limit = 100, userId, action, status, from, to } = req.query;
    const offset = (page - 1) * limit;

    let where = '1=1';
    const replacements = [];
    if (userId)  { where += ' AND user_id = ?'; replacements.push(userId); }
    if (action)  { where += ' AND action = ?'; replacements.push(action); }
    if (status)  { where += ' AND status = ?'; replacements.push(status); }
    if (from)    { where += ' AND created_at >= ?'; replacements.push(from); }
    if (to)      { where += ' AND created_at <= ?'; replacements.push(to); }

    const [logs] = await sequelize.query(
      `SELECT * FROM audit_log WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      { replacements: [...replacements, parseInt(limit), parseInt(offset)] }
    );

    return res.json({ logs });
  } catch (err) {
    logger.error('Get audit log error:', err);
    return res.status(500).json({ error: 'Failed to fetch audit log' });
  }
};

// ── Storage Stats ─────────────────────────────────────────────

const getStorageStats = async (req, res) => {
  try {
    const [stats] = await sequelize.query(
      `SELECT
         COUNT(DISTINCT u.id) AS total_users,
         COUNT(DISTINCT sf.id) AS total_folders,
         COUNT(DISTINCT f.id) AS total_files,
         SUM(f.size_bytes) AS total_bytes_used,
         SUM(sf.quota_bytes) AS total_quota_bytes
       FROM shared_folders sf
       LEFT JOIN folder_permissions fp ON fp.folder_id = sf.id
       LEFT JOIN users u ON u.id = fp.user_id AND u.status = 'active'
       LEFT JOIN files f ON f.folder_id = sf.id AND f.is_deleted = 0
       WHERE sf.is_active = 1`
    );

    const [byCompany] = await sequelize.query(
      `SELECT c.name AS company_name, SUM(f.size_bytes) AS bytes_used, sf.quota_bytes
       FROM companies c
       JOIN shared_folders sf ON sf.company_id = c.id AND sf.is_active = 1
       LEFT JOIN files f ON f.folder_id = sf.id AND f.is_deleted = 0
       GROUP BY c.id, sf.id`
    );

    return res.json({ global: stats[0], byCompany });
  } catch (err) {
    logger.error('Storage stats error:', err);
    return res.status(500).json({ error: 'Failed to fetch storage stats' });
  }
};

// ── Helpers ───────────────────────────────────────────────────

const parseQuota = (quota) => {
  const str = String(quota).toUpperCase().trim();
  if (str.endsWith('TB')) return parseFloat(str) * 1099511627776;
  if (str.endsWith('GB')) return parseFloat(str) * 1073741824;
  if (str.endsWith('MB')) return parseFloat(str) * 1048576;
  return parseInt(str) || 1099511627776;
};

module.exports = {
  getRegistrationRequests,
  approveRequest,
  rejectRequest,
  getUsers,
  updateUserPermissions,
  suspendUser,
  getFolders,
  createFolder,
  deleteFolder,
  getAuditLog,
  getStorageStats,
};
