const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { sequelize } = require('../config/database');
const { issueTokenPair, verifyRefreshToken, revokeToken } = require('../utils/jwt');
const { generateSecret, generateQRCode, verifyToken } = require('../services/totpService');
const { sendEmail } = require('../services/emailService');
const logger = require('../utils/logger');

const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS) || 12;
const MAX_FAILED_ATTEMPTS = 5;
const LOCK_DURATION_MINUTES = 15;

// ── Validation Rules ──────────────────────────────────────────

const registerValidation = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('fullName').trim().isLength({ min: 2, max: 255 }).withMessage('Full name required'),
  body('mobile').optional().matches(/^\+?[\d\s\-()]{7,20}$/).withMessage('Invalid mobile number'),
  body('companyName').trim().isLength({ min: 1, max: 255 }).withMessage('Company name required'),
  body('companyLocation').optional().trim().isLength({ max: 255 }),
  body('industry').optional().trim().isLength({ max: 100 }),
  body('purpose').optional().trim().isLength({ max: 2000 }),
];

const loginValidation = [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 1 }),
  body('totpToken').optional().isNumeric().isLength({ min: 6, max: 6 }),
];

// ── Handlers ──────────────────────────────────────────────────

/**
 * POST /api/auth/register
 * Submit a registration request (not instant account creation)
 */
const register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, fullName, mobile, companyName, companyLocation, industry, purpose } = req.body;

  try {
    // Check existing active user
    const [existing] = await sequelize.query(
      `SELECT id FROM users WHERE email = ? LIMIT 1`,
      { replacements: [email] }
    );
    if (existing.length) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }

    // Check pending request
    const [pendingReq] = await sequelize.query(
      `SELECT id FROM registration_requests WHERE email = ? AND status = 'pending' LIMIT 1`,
      { replacements: [email] }
    );
    if (pendingReq.length) {
      return res.status(409).json({ error: 'A registration request for this email is already pending' });
    }

    const requestId = uuidv4();
    await sequelize.query(
      `INSERT INTO registration_requests (id, full_name, email, mobile, company_name, company_location, industry, purpose)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      { replacements: [requestId, fullName, email, mobile || null, companyName, companyLocation || null, industry || null, purpose || null] }
    );

    // Notify user
    await sendEmail(email, 'registrationReceived', { fullName, email, companyName, location: companyLocation });

    // Notify admin
    await sendEmail(process.env.ADMIN_EMAIL, 'adminNewRequest', {
      fullName, email, mobile, companyName, location: companyLocation, industry, purpose, requestId,
    });

    logger.info(`Registration request submitted: ${email} (${companyName})`);
    return res.status(201).json({
      message: 'Registration request submitted successfully. You will be notified by email once approved.',
      requestId,
    });
  } catch (err) {
    logger.error('Register error:', err);
    return res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
};

/**
 * POST /api/auth/login
 * Step 1: Email + Password → returns partial token if 2FA needed
 */
const login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }

  const { email, password, totpToken } = req.body;
  const ip = req.ip;
  const userAgent = req.headers['user-agent'] || '';

  try {
    const [users] = await sequelize.query(
      `SELECT id, email, full_name, password_hash, role, status, totp_enabled, totp_secret,
              totp_verified, company_id, failed_login_attempts, locked_until
       FROM users WHERE email = ? LIMIT 1`,
      { replacements: [email] }
    );

    // Generic error to prevent user enumeration
    const invalidError = () => res.status(401).json({ error: 'Invalid email or password' });

    if (!users.length) return invalidError();
    const user = users[0];

    // Check account status
    if (user.status === 'pending') {
      return res.status(403).json({ error: 'Your account is pending admin approval' });
    }
    if (user.status === 'suspended') {
      return res.status(403).json({ error: 'Your account has been suspended. Contact support.' });
    }
    if (user.status === 'rejected') {
      return res.status(403).json({ error: 'Account registration was rejected' });
    }

    // Check account lockout
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const minutesLeft = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      return res.status(429).json({
        error: `Account temporarily locked due to failed attempts. Try again in ${minutesLeft} minutes.`,
      });
    }

    // Verify password
    const passwordValid = await bcrypt.compare(password, user.password_hash);
    if (!passwordValid) {
      const attempts = user.failed_login_attempts + 1;
      const lockUntil = attempts >= MAX_FAILED_ATTEMPTS
        ? new Date(Date.now() + LOCK_DURATION_MINUTES * 60000)
        : null;

      await sequelize.query(
        `UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?`,
        { replacements: [attempts, lockUntil, user.id] }
      );

      // Audit log
      await sequelize.query(
        `INSERT INTO audit_log (user_id, user_email, action, ip_address, user_agent, status)
         VALUES (?, ?, 'LOGIN_FAIL', ?, ?, 'failure')`,
        { replacements: [user.id, email, ip, userAgent.substring(0, 500)] }
      );

      return invalidError();
    }

    // Verify TOTP if enabled
    if (user.totp_enabled && user.totp_verified) {
      if (!totpToken) {
        return res.status(200).json({
          requiresTOTP: true,
          message: 'Please provide your 2FA code',
        });
      }

      const totpValid = verifyToken(totpToken, user.totp_secret);
      if (!totpValid) {
        await sequelize.query(
          `INSERT INTO audit_log (user_id, user_email, action, ip_address, status)
           VALUES (?, ?, 'LOGIN_2FA_FAIL', ?, 'failure')`,
          { replacements: [user.id, email, ip] }
        );
        return res.status(401).json({ error: 'Invalid 2FA code' });
      }
    }

    // Reset failed attempts, update last login
    await sequelize.query(
      `UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = NOW(), last_login_ip = ?
       WHERE id = ?`,
      { replacements: [ip, user.id] }
    );

    const { accessToken, refreshToken } = issueTokenPair(user);

    // Store session
    await sequelize.query(
      `INSERT INTO user_sessions (id, user_id, refresh_token_hash, ip_address, user_agent, expires_at)
       VALUES (?, ?, SHA2(?, 256), ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))`,
      { replacements: [uuidv4(), user.id, refreshToken, ip, userAgent.substring(0, 500)] }
    );

    // Audit success
    await sequelize.query(
      `INSERT INTO audit_log (user_id, user_email, action, ip_address, user_agent, status)
       VALUES (?, ?, 'LOGIN_SUCCESS', ?, ?, 'success')`,
      { replacements: [user.id, email, ip, userAgent.substring(0, 500)] }
    );

    logger.info(`Login success: ${email} from ${ip}`);

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.status(200).json({
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name,
        role: user.role,
        companyId: user.company_id,
        totpEnabled: !!user.totp_enabled,
      },
    });
  } catch (err) {
    logger.error('Login error:', err);
    return res.status(500).json({ error: 'Login failed' });
  }
};

/**
 * POST /api/auth/2fa/setup
 * Generate TOTP secret and QR code for authenticated user
 */
const setup2FA = async (req, res) => {
  try {
    const { base32, otpauth_url } = generateSecret(req.user.email);
    const qrCode = await generateQRCode(otpauth_url);

    // Store secret temporarily (not enabled until verified)
    await sequelize.query(
      `UPDATE users SET totp_secret = ?, totp_verified = 0 WHERE id = ?`,
      { replacements: [base32, req.user.id] }
    );

    return res.json({
      secret: base32,
      qrCode,
      message: 'Scan the QR code with your authenticator app, then verify with a code',
    });
  } catch (err) {
    logger.error('2FA setup error:', err);
    return res.status(500).json({ error: '2FA setup failed' });
  }
};

/**
 * POST /api/auth/2fa/verify
 * Verify TOTP and enable 2FA for the account
 */
const verify2FA = async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'TOTP token required' });

  try {
    const [users] = await sequelize.query(
      `SELECT totp_secret FROM users WHERE id = ? LIMIT 1`,
      { replacements: [req.user.id] }
    );

    if (!users.length || !users[0].totp_secret) {
      return res.status(400).json({ error: 'Run 2FA setup first' });
    }

    const valid = verifyToken(token, users[0].totp_secret);
    if (!valid) return res.status(400).json({ error: 'Invalid TOTP code' });

    await sequelize.query(
      `UPDATE users SET totp_enabled = 1, totp_verified = 1 WHERE id = ?`,
      { replacements: [req.user.id] }
    );

    logger.info(`2FA enabled for user: ${req.user.email}`);
    return res.json({ message: '2FA enabled successfully' });
  } catch (err) {
    logger.error('2FA verify error:', err);
    return res.status(500).json({ error: '2FA verification failed' });
  }
};

/**
 * POST /api/auth/refresh
 * Issue new access token from refresh token
 */
const refreshToken = async (req, res) => {
  try {
    const token = req.cookies.refreshToken || req.body.refreshToken;
    if (!token) return res.status(401).json({ error: 'Refresh token required' });

    const decoded = verifyRefreshToken(token);

    const [users] = await sequelize.query(
      `SELECT id, email, full_name, role, status, company_id, totp_enabled
       FROM users WHERE id = ? AND status = 'active' LIMIT 1`,
      { replacements: [decoded.sub] }
    );

    if (!users.length) return res.status(401).json({ error: 'User not found' });

    // Verify session still valid
    const [sessions] = await sequelize.query(
      `SELECT id FROM user_sessions
       WHERE user_id = ? AND SHA2(?, 256) = refresh_token_hash
       AND is_revoked = 0 AND expires_at > NOW() LIMIT 1`,
      { replacements: [decoded.sub, token] }
    );

    if (!sessions.length) return res.status(401).json({ error: 'Session expired or revoked' });

    const { accessToken } = issueTokenPair(users[0]);
    return res.json({ accessToken });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid refresh token' });
  }
};

/**
 * POST /api/auth/logout
 */
const logout = async (req, res) => {
  try {
    const token = req.cookies.refreshToken || req.body.refreshToken;

    if (token && req.user) {
      // Revoke session in DB
      await sequelize.query(
        `UPDATE user_sessions SET is_revoked = 1
         WHERE user_id = ? AND SHA2(?, 256) = refresh_token_hash`,
        { replacements: [req.user.id, token] }
      );

      // Blacklist access token
      const authHeader = req.headers.authorization;
      if (authHeader?.startsWith('Bearer ')) {
        await revokeToken(authHeader.split(' ')[1]);
      }
    }

    res.clearCookie('refreshToken');
    return res.json({ message: 'Logged out successfully' });
  } catch (err) {
    logger.error('Logout error:', err);
    return res.json({ message: 'Logged out' });
  }
};

module.exports = {
  register,
  login,
  setup2FA,
  verify2FA,
  refreshToken,
  logout,
  registerValidation,
  loginValidation,
};
