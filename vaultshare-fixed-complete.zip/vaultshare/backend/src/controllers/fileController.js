const { v4: uuidv4 } = require('uuid');
const { Readable } = require('stream');
const { sequelize } = require('../config/database');
const {
  uploadFileToS3,
  getPresignedDownloadUrl,
  getPresignedUploadUrl,
  deleteFileFromS3,
} = require('../services/s3Service');
const logger = require('../utils/logger');

/**
 * GET /api/folders/:folderId/files
 * List all files in a folder
 */
const listFiles = async (req, res) => {
  try {
    const { folderId } = req.params;
    const { search, page = 1, limit = 100 } = req.query;
    const offset = (page - 1) * limit;

    let where = 'f.folder_id = ? AND f.is_deleted = 0';
    const replacements = [folderId];

    if (search) {
      where += ' AND f.original_name LIKE ?';
      replacements.push(`%${search}%`);
    }

    const [files] = await sequelize.query(
      `SELECT f.id, f.original_name, f.mime_type, f.size_bytes, f.checksum_sha256,
              f.version, f.created_at, f.updated_at,
              u.full_name AS uploaded_by_name, u.email AS uploaded_by_email
       FROM files f
       JOIN users u ON u.id = f.uploaded_by
       WHERE ${where}
       ORDER BY f.created_at DESC
       LIMIT ? OFFSET ?`,
      { replacements: [...replacements, parseInt(limit), parseInt(offset)] }
    );

    const [[{ total }]] = await sequelize.query(
      `SELECT COUNT(*) AS total FROM files WHERE folder_id = ? AND is_deleted = 0`,
      { replacements: [folderId] }
    );

    return res.json({ files, total });
  } catch (err) {
    logger.error('List files error:', err);
    return res.status(500).json({ error: 'Failed to list files' });
  }
};

/**
 * POST /api/folders/:folderId/files/upload
 * Upload file via server (multipart/form-data)
 */
const uploadFile = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const { folderId } = req.params;

    // Verify folder exists and get name
    const [folders] = await sequelize.query(
      `SELECT id, folder_name, quota_bytes, used_bytes FROM shared_folders WHERE id = ? AND is_active = 1 LIMIT 1`,
      { replacements: [folderId], transaction: t }
    );
    if (!folders.length) {
      await t.rollback();
      return res.status(404).json({ error: 'Folder not found' });
    }
    const folder = folders[0];

    const files = req.files || [req.file];
    const uploaded = [];

    for (const file of files) {
      // Check quota
      const newUsed = folder.used_bytes + file.size;
      if (newUsed > folder.quota_bytes) {
        await t.rollback();
        return res.status(413).json({ error: 'Folder quota exceeded' });
      }

      // Convert buffer to stream for S3
      const stream = Readable.from(file.buffer);

      const { s3Key } = await uploadFileToS3({
        stream,
        folderName: folder.folder_name,
        originalName: file.originalname,
        mimeType: file.mimetype,
        userId: req.user.id,
      });

      const fileId = uuidv4();
      await sequelize.query(
        `INSERT INTO files (id, folder_id, uploaded_by, original_name, s3_key, mime_type, size_bytes, checksum_sha256)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        { replacements: [fileId, folderId, req.user.id, file.originalname, s3Key, file.mimetype, file.size, file.checksum || null], transaction: t }
      );

      // Update folder usage
      await sequelize.query(
        `UPDATE shared_folders SET used_bytes = used_bytes + ? WHERE id = ?`,
        { replacements: [file.size, folderId], transaction: t }
      );

      uploaded.push({ id: fileId, name: file.originalname, size: file.size, s3Key });
    }

    // Audit
    await sequelize.query(
      `INSERT INTO audit_log (user_id, user_email, action, resource_type, resource_name, ip_address, status)
       VALUES (?, ?, 'FILE_UPLOAD', 'file', ?, ?, 'success')`,
      { replacements: [req.user.id, req.user.email, uploaded.map(f => f.name).join(', '), req.ip], transaction: t }
    );

    await t.commit();
    logger.info(`Files uploaded: ${uploaded.length} files to ${folder.folder_name} by ${req.user.email}`);
    return res.status(201).json({ message: 'Files uploaded', files: uploaded });
  } catch (err) {
    await t.rollback();
    logger.error('Upload error:', err);
    return res.status(500).json({ error: 'Upload failed' });
  }
};

/**
 * GET /api/files/:fileId/download
 * Get a pre-signed download URL (expires in 1 hour)
 */
const downloadFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    const userId = req.user.id;

    const [files] = await sequelize.query(
      `SELECT f.id, f.original_name, f.s3_key, f.folder_id, fp.permission
       FROM files f
       JOIN folder_permissions fp ON fp.folder_id = f.folder_id
       WHERE f.id = ? AND fp.user_id = ? AND f.is_deleted = 0
       AND (fp.permission = 'read' OR fp.permission = 'write')
       AND (fp.expires_at IS NULL OR fp.expires_at > NOW())
       LIMIT 1`,
      { replacements: [fileId, userId] }
    );

    // Admin override
    let file;
    if (!files.length && req.user.role === 'admin') {
      const [adminFiles] = await sequelize.query(
        `SELECT id, original_name, s3_key, folder_id FROM files WHERE id = ? AND is_deleted = 0 LIMIT 1`,
        { replacements: [fileId] }
      );
      if (!adminFiles.length) return res.status(404).json({ error: 'File not found' });
      file = adminFiles[0];
    } else if (!files.length) {
      return res.status(403).json({ error: 'No permission to access this file' });
    } else {
      file = files[0];
    }

    const url = await getPresignedDownloadUrl(file.s3_key, file.original_name);

    // Audit
    await sequelize.query(
      `INSERT INTO audit_log (user_id, user_email, action, resource_type, resource_id, resource_name, ip_address, status)
       VALUES (?, ?, 'FILE_DOWNLOAD', 'file', ?, ?, ?, 'success')`,
      { replacements: [req.user.id, req.user.email, fileId, file.original_name, req.ip] }
    );

    return res.json({ downloadUrl: url, expiresIn: parseInt(process.env.S3_PRESIGNED_URL_EXPIRY) || 3600 });
  } catch (err) {
    logger.error('Download error:', err);
    return res.status(500).json({ error: 'Download failed' });
  }
};

/**
 * DELETE /api/files/:fileId
 * Soft-delete a file (write permission required)
 */
const deleteFile = async (req, res) => {
  try {
    const { fileId } = req.params;

    const [files] = await sequelize.query(
      `SELECT f.id, f.s3_key, f.size_bytes, f.folder_id, f.original_name
       FROM files f WHERE f.id = ? AND f.is_deleted = 0 LIMIT 1`,
      { replacements: [fileId] }
    );
    if (!files.length) return res.status(404).json({ error: 'File not found' });

    const file = files[0];

    await sequelize.query(
      `UPDATE files SET is_deleted = 1, deleted_by = ?, deleted_at = NOW() WHERE id = ?`,
      { replacements: [req.user.id, fileId] }
    );

    await sequelize.query(
      `UPDATE shared_folders SET used_bytes = GREATEST(0, used_bytes - ?) WHERE id = ?`,
      { replacements: [file.size_bytes, file.folder_id] }
    );

    await sequelize.query(
      `INSERT INTO audit_log (user_id, user_email, action, resource_type, resource_id, resource_name, ip_address, status)
       VALUES (?, ?, 'FILE_DELETE', 'file', ?, ?, ?, 'warning')`,
      { replacements: [req.user.id, req.user.email, fileId, file.original_name, req.ip] }
    );

    logger.info(`File soft-deleted: ${file.original_name} by ${req.user.email}`);
    return res.json({ message: 'File deleted' });
  } catch (err) {
    logger.error('Delete error:', err);
    return res.status(500).json({ error: 'Delete failed' });
  }
};

/**
 * GET /api/folders/:folderId/presigned-upload
 * Get a pre-signed URL for direct browser → S3 upload
 */
const getUploadUrl = async (req, res) => {
  try {
    const { folderId } = req.params;
    const { filename, mimeType } = req.query;

    if (!filename || !mimeType) {
      return res.status(400).json({ error: 'filename and mimeType required' });
    }

    const [folders] = await sequelize.query(
      `SELECT folder_name FROM shared_folders WHERE id = ? AND is_active = 1 LIMIT 1`,
      { replacements: [folderId] }
    );
    if (!folders.length) return res.status(404).json({ error: 'Folder not found' });

    const { url, s3Key } = await getPresignedUploadUrl(folders[0].folder_name, filename, mimeType);
    return res.json({ uploadUrl: url, s3Key, expiresIn: 300 });
  } catch (err) {
    logger.error('Presigned URL error:', err);
    return res.status(500).json({ error: 'Failed to generate upload URL' });
  }
};

module.exports = { listFiles, uploadFile, downloadFile, deleteFile, getUploadUrl };
