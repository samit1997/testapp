const { verifyAccessToken } = require('../utils/jwt');
const { sequelize } = require('../config/database');
const logger = require('../utils/logger');

/**
 * Core authentication middleware
 * Validates JWT, checks user status, injects req.user
 */
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = await verifyAccessToken(token);

    // Fetch fresh user from DB (catches suspended/deleted accounts)
    const [users] = await sequelize.query(
      `SELECT id, email, full_name, role, status, totp_enabled, company_id
       FROM users WHERE id = ? AND status = 'active' LIMIT 1`,
      { replacements: [decoded.userId] }
    );

    if (!users.length) {
      return res.status(401).json({ error: 'Account not found or suspended' });
    }

    req.user = { ...users[0], jti: decoded.jti };
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token' });
    }
    logger.error('Auth middleware error:', err);
    return res.status(401).json({ error: 'Authentication failed' });
  }
};

/**
 * Require admin role
 */
const requireAdmin = (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  if (req.user.role !== 'admin') {
    logger.warn(`Unauthorized admin access attempt by ${req.user.email} (${req.user.id})`);
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

/**
 * Require 2FA to be enabled and verified
 */
const require2FA = (req, res, next) => {
  if (!req.user?.totp_enabled) {
    return res.status(403).json({
      error: '2FA required',
      code: '2FA_SETUP_REQUIRED',
      message: 'Please enable Two-Factor Authentication before accessing this resource',
    });
  }
  next();
};

/**
 * Check folder permission (inject after authenticate)
 * Usage: checkFolderPermission('read') or checkFolderPermission('write')
 */
const checkFolderPermission = (required = 'read') => async (req, res, next) => {
  try {
    const folderId = req.params.folderId || req.body.folderId;
    if (!folderId) return res.status(400).json({ error: 'Folder ID required' });

    // Admins always have access
    if (req.user.role === 'admin') return next();

    const [perms] = await sequelize.query(
      `SELECT fp.permission, sf.is_active
       FROM folder_permissions fp
       JOIN shared_folders sf ON sf.id = fp.folder_id
       WHERE fp.user_id = ? AND fp.folder_id = ?
       AND (fp.expires_at IS NULL OR fp.expires_at > NOW())
       LIMIT 1`,
      { replacements: [req.user.id, folderId] }
    );

    if (!perms.length || !perms[0].is_active) {
      return res.status(403).json({ error: 'No access to this folder' });
    }

    const perm = perms[0].permission;

    if (required === 'write' && perm !== 'write') {
      return res.status(403).json({ error: 'Write permission required' });
    }

    if (perm === 'none') {
      return res.status(403).json({ error: 'Access revoked' });
    }

    req.folderPermission = perm;
    next();
  } catch (err) {
    logger.error('Permission check error:', err);
    return res.status(500).json({ error: 'Permission check failed' });
  }
};

/**
 * Audit logging middleware — logs all authenticated requests
 */
const auditLog = (action, resourceType = null) => async (req, res, next) => {
  const originalJson = res.json.bind(res);
  res.json = async (body) => {
    const status = res.statusCode >= 200 && res.statusCode < 400 ? 'success' : 'failure';
    try {
      await sequelize.query(
        `INSERT INTO audit_log (user_id, user_email, action, resource_type, resource_id, resource_name, ip_address, user_agent, status, details)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        {
          replacements: [
            req.user?.id || null,
            req.user?.email || null,
            action,
            resourceType,
            req.params.id || req.params.folderId || req.params.fileId || null,
            null,
            req.ip,
            req.headers['user-agent']?.substring(0, 500) || null,
            status,
            JSON.stringify({ method: req.method, path: req.path, statusCode: res.statusCode }),
          ],
        }
      );
    } catch (e) {
      logger.error('Audit log error:', e);
    }
    return originalJson(body);
  };
  next();
};

module.exports = {
  authenticate,
  requireAdmin,
  require2FA,
  checkFolderPermission,
  auditLog,
};
