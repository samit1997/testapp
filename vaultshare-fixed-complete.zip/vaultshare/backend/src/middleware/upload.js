const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const logger = require('../utils/logger');

const MAX_SIZE = parseInt(process.env.MAX_FILE_SIZE_MB || '500') * 1024 * 1024;

const ALLOWED_MIME_TYPES = (process.env.ALLOWED_MIME_TYPES || '')
  .split(',')
  .map((t) => t.trim())
  .filter(Boolean);

// Dangerous extensions to always block regardless of MIME
const BLOCKED_EXTENSIONS = new Set([
  '.exe', '.bat', '.cmd', '.sh', '.ps1', '.msi', '.dll', '.so',
  '.js', '.vbs', '.wsf', '.scr', '.pif', '.com', '.lnk',
  '.php', '.py', '.rb', '.pl', '.cgi',
]);

// Use memory storage — we pipe directly to S3 and never touch disk
const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  // Check extension
  const ext = path.extname(file.originalname).toLowerCase();
  if (BLOCKED_EXTENSIONS.has(ext)) {
    logger.warn(`Blocked dangerous file extension: ${ext} from ${req.user?.email}`);
    return cb(new Error(`File type not allowed: ${ext}`), false);
  }

  // Check MIME type
  if (ALLOWED_MIME_TYPES.length && !ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    logger.warn(`Blocked MIME type: ${file.mimetype} from ${req.user?.email}`);
    return cb(new Error(`MIME type not allowed: ${file.mimetype}`), false);
  }

  cb(null, true);
};

const upload = multer({
  storage,
  limits: {
    fileSize: MAX_SIZE,
    files: 10, // max 10 files per request
  },
  fileFilter,
});

/**
 * Sanitize filename to prevent path traversal
 */
const sanitizeFilename = (name) => {
  return name
    .replace(/\.\./g, '')
    .replace(/[/\\]/g, '')
    .replace(/[^\w\s.-]/g, '_')
    .trim()
    .substring(0, 255);
};

/**
 * Stub for antivirus scanning
 * In production: integrate with AWS GuardDuty / ClamAV / Trend Micro
 */
const scanForViruses = async (buffer, filename) => {
  // TODO: integrate ClamAV or cloud AV service
  // Example: POST buffer to internal AV microservice
  // For now: log and pass through
  logger.info(`AV scan: ${filename} (${buffer.length} bytes) — PASSED (stub)`);

  // Basic magic byte checks for obvious dangers
  const hex = buffer.slice(0, 4).toString('hex');
  const dangerousSignatures = [
    '4d5a9000', // PE executable (MZ header)
    '7f454c46', // ELF binary
  ];

  if (dangerousSignatures.some((sig) => hex.startsWith(sig))) {
    throw new Error('Potentially dangerous file detected');
  }

  return { clean: true, engine: 'basic-stub' };
};

/**
 * Compute SHA-256 checksum of buffer
 */
const computeChecksum = (buffer) => {
  return crypto.createHash('sha256').update(buffer).digest('hex');
};

/**
 * Middleware: validate uploaded files post-multer
 */
const validateUpload = async (req, res, next) => {
  try {
    if (!req.files?.length && !req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const files = req.files || [req.file];

    for (const file of files) {
      // Sanitize filename
      file.originalname = sanitizeFilename(file.originalname);

      // AV scan
      await scanForViruses(file.buffer, file.originalname);

      // Compute checksum
      file.checksum = computeChecksum(file.buffer);
    }

    next();
  } catch (err) {
    logger.warn(`File validation failed: ${err.message}`);
    return res.status(400).json({ error: err.message });
  }
};

/**
 * Handle multer errors
 */
const handleMulterError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: `File too large. Max size: ${process.env.MAX_FILE_SIZE_MB || 500}MB` });
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({ error: 'Too many files. Max 10 per request' });
    }
    return res.status(400).json({ error: `Upload error: ${err.message}` });
  }
  next(err);
};

module.exports = {
  upload,
  validateUpload,
  handleMulterError,
  sanitizeFilename,
  scanForViruses,
  computeChecksum,
};
