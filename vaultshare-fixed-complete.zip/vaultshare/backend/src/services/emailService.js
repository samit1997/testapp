const nodemailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

// Local SMTP (Mailpit)
const transporter = nodemailer.createTransport({
  host:   process.env.SMTP_HOST || '127.0.0.1',
  port:   parseInt(process.env.SMTP_PORT || '1025'),
  secure: false,
  tls:    { rejectUnauthorized: false },
});

// ── HTML Email Base Template ──────────────────────────────────
const baseTemplate = (content) => `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VaultShare</title>
<style>
  body { margin: 0; padding: 0; background: #f6f8fa; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
  .container { max-width: 560px; margin: 40px auto; background: #ffffff; border-radius: 8px; overflow: hidden; border: 1px solid #d0d7de; }
  .header { background: #0d1117; padding: 24px 32px; }
  .logo { color: #ffffff; font-size: 18px; font-weight: 700; letter-spacing: 0.06em; font-family: monospace; }
  .logo span { color: #0969da; }
  .body { padding: 32px; }
  .body h2 { color: #0d1117; font-size: 20px; margin: 0 0 16px; }
  .body p { color: #57606a; font-size: 14px; line-height: 1.7; margin: 0 0 16px; }
  .btn { display: inline-block; padding: 10px 20px; background: #0969da; color: #ffffff; text-decoration: none; border-radius: 6px; font-size: 14px; font-weight: 600; margin: 8px 0; }
  .info-box { background: #f6f8fa; border: 1px solid #d0d7de; border-radius: 6px; padding: 16px; margin: 16px 0; }
  .info-row { display: flex; justify-content: space-between; margin: 4px 0; font-size: 13px; }
  .info-label { color: #57606a; }
  .info-value { color: #0d1117; font-weight: 600; font-family: monospace; }
  .footer { background: #f6f8fa; padding: 16px 32px; border-top: 1px solid #d0d7de; }
  .footer p { color: #8b949e; font-size: 12px; margin: 0; line-height: 1.6; }
  .alert-warn { background: #fff8c5; border: 1px solid #d4a72c; border-radius: 6px; padding: 12px 16px; margin: 16px 0; font-size: 13px; color: #9a6700; }
  .code { font-family: monospace; background: #f6f8fa; border: 1px solid #d0d7de; padding: 2px 6px; border-radius: 4px; font-size: 13px; color: #0969da; }
</style>
</head>
<body>
<div class="container">
  <div class="header"><div class="logo">VAULT<span>SHARE</span></div></div>
  <div class="body">${content}</div>
  <div class="footer">
    <p>This is an automated notification from VaultShare Enterprise. Do not reply to this email.<br>
    If you did not request this, please contact <a href="mailto:security@vaultshare.io">security@vaultshare.io</a> immediately.<br>
    &copy; ${new Date().getFullYear()} VaultShare · All actions are logged and monitored.</p>
  </div>
</div>
</body>
</html>
`;

// ── Email Templates ───────────────────────────────────────────

const templates = {
  registrationReceived: (data) => ({
    subject: 'Registration Request Received — VaultShare',
    html: baseTemplate(`
      <h2>Request Received</h2>
      <p>Hi ${data.fullName},</p>
      <p>We've received your registration request for <strong>VaultShare</strong>. Our admin team will review your application and get back to you within 1–2 business days.</p>
      <div class="info-box">
        <div class="info-row"><span class="info-label">Name</span><span class="info-value">${data.fullName}</span></div>
        <div class="info-row"><span class="info-label">Email</span><span class="info-value">${data.email}</span></div>
        <div class="info-row"><span class="info-label">Company</span><span class="info-value">${data.companyName}</span></div>
        <div class="info-row"><span class="info-label">Location</span><span class="info-value">${data.location}</span></div>
        <div class="info-row"><span class="info-label">Submitted</span><span class="info-value">${new Date().toUTCString()}</span></div>
      </div>
      <p>You will receive an email once your account is approved with your login credentials and assigned folder details.</p>
    `),
  }),

  adminNewRequest: (data) => ({
    subject: `[ACTION REQUIRED] New Registration: ${data.fullName} — ${data.companyName}`,
    html: baseTemplate(`
      <h2>New Registration Request</h2>
      <p>A new user has requested access to VaultShare. Please review and approve or reject.</p>
      <div class="info-box">
        <div class="info-row"><span class="info-label">Full Name</span><span class="info-value">${data.fullName}</span></div>
        <div class="info-row"><span class="info-label">Email</span><span class="info-value">${data.email}</span></div>
        <div class="info-row"><span class="info-label">Mobile</span><span class="info-value">${data.mobile || 'N/A'}</span></div>
        <div class="info-row"><span class="info-label">Company</span><span class="info-value">${data.companyName}</span></div>
        <div class="info-row"><span class="info-label">Location</span><span class="info-value">${data.location}</span></div>
        <div class="info-row"><span class="info-label">Industry</span><span class="info-value">${data.industry || 'N/A'}</span></div>
        <div class="info-row"><span class="info-label">Purpose</span><span class="info-value">${data.purpose || 'N/A'}</span></div>
      </div>
      <a href="${process.env.FRONTEND_URL}/admin/requests/${data.requestId}" class="btn">Review Request →</a>
    `),
  }),

  accountApproved: (data) => ({
    subject: '✓ Account Approved — VaultShare Access Granted',
    html: baseTemplate(`
      <h2>Your Account Has Been Approved</h2>
      <p>Hi ${data.fullName},</p>
      <p>Great news — your VaultShare account has been approved. You can now log in and access your shared folder.</p>
      <div class="info-box">
        <div class="info-row"><span class="info-label">Username (Email)</span><span class="info-value">${data.email}</span></div>
        <div class="info-row"><span class="info-label">Assigned Folder</span><span class="info-value">${data.folderName}</span></div>
        <div class="info-row"><span class="info-label">Permissions</span><span class="info-value">${data.permissions === 'write' ? 'Read / Write' : 'Read Only'}</span></div>
        <div class="info-row"><span class="info-label">Storage Quota</span><span class="info-value">${data.quota}</span></div>
        <div class="info-row"><span class="info-label">Temp Password</span><span class="info-value">${data.tempPassword}</span></div>
      </div>
      <div class="alert-warn">⚠ You must change your password and set up 2FA on first login. Your temp password expires in 24 hours.</div>
      <a href="${process.env.FRONTEND_URL}/login" class="btn">Login to VaultShare →</a>
      <p style="margin-top:20px;font-size:13px;color:#57606a;">
        <strong>Security reminder:</strong> VaultShare requires Two-Factor Authentication (TOTP). 
        Download Google Authenticator, Authy, or Microsoft Authenticator before logging in.
      </p>
    `),
  }),

  accountRejected: (data) => ({
    subject: 'Registration Update — VaultShare',
    html: baseTemplate(`
      <h2>Registration Status Update</h2>
      <p>Hi ${data.fullName},</p>
      <p>Thank you for your interest in VaultShare. After review, we are unable to approve your registration at this time.</p>
      ${data.reason ? `<div class="info-box"><p style="margin:0;font-size:13px;color:#57606a;"><strong>Reason:</strong> ${data.reason}</p></div>` : ''}
      <p>If you believe this is in error, please contact <a href="mailto:support@vaultshare.io">support@vaultshare.io</a>.</p>
    `),
  }),

  loginAlert: (data) => ({
    subject: '⚠ New Login Detected — VaultShare',
    html: baseTemplate(`
      <h2>New Login to Your Account</h2>
      <p>Hi ${data.fullName},</p>
      <p>We detected a new login to your VaultShare account. If this was you, no action is needed.</p>
      <div class="info-box">
        <div class="info-row"><span class="info-label">Time</span><span class="info-value">${data.time}</span></div>
        <div class="info-row"><span class="info-label">IP Address</span><span class="info-value">${data.ip}</span></div>
        <div class="info-row"><span class="info-label">Location</span><span class="info-value">${data.location || 'Unknown'}</span></div>
        <div class="info-row"><span class="info-label">Device</span><span class="info-value">${data.device}</span></div>
      </div>
      <div class="alert-warn">🚨 If this was NOT you, contact security@vaultshare.io immediately and change your password.</div>
    `),
  }),

  passwordReset: (data) => ({
    subject: 'Password Reset Request — VaultShare',
    html: baseTemplate(`
      <h2>Reset Your Password</h2>
      <p>Hi ${data.fullName},</p>
      <p>We received a request to reset your VaultShare password. Click the button below to proceed. This link expires in <strong>15 minutes</strong>.</p>
      <a href="${process.env.FRONTEND_URL}/reset-password?token=${data.token}" class="btn">Reset Password →</a>
      <p style="margin-top:16px;font-size:13px;color:#57606a;">If you did not request this, ignore this email — your password will not change.</p>
    `),
  }),
};

// ── Send Email ────────────────────────────────────────────────
const sendEmail = async (to, templateName, data, db = null) => {
  const template = templates[templateName];
  if (!template) throw new Error(`Unknown email template: ${templateName}`);

  const { subject, html } = template(data);
  const notifId = uuidv4();

  try {
    const info = await transporter.sendMail({
      from: `"${process.env.SES_FROM_NAME}" <${process.env.SES_FROM_EMAIL}>`,
      to,
      subject,
      html,
    });

    logger.info(`Email sent: ${templateName} → ${to} (${info.messageId})`);

    // Log to DB if connection available
    if (db) {
      await db.query(
        `INSERT INTO email_notifications (id, recipient_email, template, subject, status, ses_message_id, sent_at)
         VALUES (?, ?, ?, ?, 'sent', ?, NOW())`,
        [notifId, to, templateName, subject, info.messageId]
      );
    }

    return { success: true, messageId: info.messageId };
  } catch (err) {
    logger.error(`Email failed: ${templateName} → ${to}:`, err);

    if (db) {
      await db.query(
        `INSERT INTO email_notifications (id, recipient_email, template, subject, status, error_message)
         VALUES (?, ?, ?, ?, 'failed', ?)`,
        [notifId, to, templateName, subject, err.message]
      );
    }

    throw err;
  }
};

module.exports = { sendEmail, templates };
