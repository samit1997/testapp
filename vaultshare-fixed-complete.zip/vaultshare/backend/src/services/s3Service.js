/**
 * s3Service.js — LOCAL DISK version (no AWS S3)
 * Stores files at LOCAL_STORAGE_PATH on the server.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');

const BASE_DIR = process.env.LOCAL_STORAGE_PATH || '/var/www/vaultshare/uploads';
if (!fs.existsSync(BASE_DIR)) fs.mkdirSync(BASE_DIR, { recursive: true });

const buildS3Key = (folderName, originalName) => {
  const safeName = originalName.replace(/[^a-zA-Z0-9._-]/g, '_');
  return path.join(folderName, `${uuidv4()}-${safeName}`);
};

const uploadFileToS3 = ({ stream, folderName, originalName, mimeType, userId }) =>
  new Promise((resolve, reject) => {
    const relKey = buildS3Key(folderName, originalName);
    const absPath = path.join(BASE_DIR, relKey);
    fs.mkdirSync(path.dirname(absPath), { recursive: true });
    const ws = fs.createWriteStream(absPath);
    stream.pipe(ws);
    ws.on('finish', () => { logger.info(`File saved: ${relKey}`); resolve({ s3Key: relKey, location: absPath }); });
    ws.on('error', reject);
  });

const getPresignedDownloadUrl = async (s3Key, filename) => {
  const base = process.env.FRONTEND_URL || 'http://localhost';
  return `${base}/api/files/serve?key=${encodeURIComponent(s3Key)}&name=${encodeURIComponent(filename)}`;
};

const getPresignedUploadUrl = async (folderName, originalName) =>
  ({ url: null, s3Key: buildS3Key(folderName, originalName) });

const markFileDeletedOnS3 = async (s3Key) => logger.info(`Marked deleted: ${s3Key}`);

const deleteFileFromS3 = async (s3Key) => {
  const p = path.join(BASE_DIR, s3Key);
  if (fs.existsSync(p)) { fs.unlinkSync(p); logger.info(`Deleted: ${s3Key}`); }
};

const getFileMetadata = async (s3Key) => {
  const stat = fs.statSync(path.join(BASE_DIR, s3Key));
  return { size: stat.size, lastModified: stat.mtime, contentType: 'application/octet-stream' };
};

const listFolderContents = async (folderName) => {
  const dir = path.join(BASE_DIR, folderName);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).map(f => ({ Key: path.join(folderName, f) }));
};

const calculateChecksum = (buffer) =>
  crypto.createHash('sha256').update(buffer).digest('hex');

module.exports = {
  uploadFileToS3, getPresignedDownloadUrl, getPresignedUploadUrl,
  markFileDeletedOnS3, deleteFileFromS3, getFileMetadata,
  listFolderContents, buildS3Key, calculateChecksum, BASE_DIR,
};
