const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const logger = require('../utils/logger');

const ISSUER = process.env.TOTP_ISSUER || 'VaultShare';
const STEP = 30;      // 30-second window
const WINDOW = 1;     // Accept 1 step before/after (clock drift tolerance)
const DIGITS = 6;

/**
 * Generate a new TOTP secret for a user
 */
const generateSecret = (email) => {
  const secret = speakeasy.generateSecret({
    name: `${ISSUER}:${email}`,
    issuer: ISSUER,
    length: 20,
  });
  return {
    base32: secret.base32,
    otpauth_url: secret.otpauth_url,
  };
};

/**
 * Generate QR code as a data URL for the authenticator app
 */
const generateQRCode = async (otpauthUrl) => {
  try {
    const dataUrl = await QRCode.toDataURL(otpauthUrl, {
      width: 200,
      margin: 2,
      color: { dark: '#0d1117', light: '#ffffff' },
    });
    return dataUrl;
  } catch (err) {
    logger.error('QR code generation failed:', err);
    throw err;
  }
};

/**
 * Verify a TOTP token against a stored secret
 */
const verifyToken = (token, secret) => {
  if (!token || !secret) return false;

  // Sanitize: only accept 6-digit numeric codes
  const clean = String(token).replace(/\s/g, '');
  if (!/^\d{6}$/.test(clean)) return false;

  return speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token: clean,
    step: STEP,
    window: WINDOW,
    digits: DIGITS,
  });
};

/**
 * Generate a current TOTP (for testing only — never expose in production)
 */
const generateCurrentToken = (secret) => {
  return speakeasy.totp({
    secret,
    encoding: 'base32',
    step: STEP,
    digits: DIGITS,
  });
};

module.exports = {
  generateSecret,
  generateQRCode,
  verifyToken,
  generateCurrentToken,
};
