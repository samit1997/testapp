const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { blacklistToken, isTokenBlacklisted } = require('../config/redis');
const logger = require('./logger');

const ACCESS_SECRET  = process.env.JWT_SECRET;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;
const ACCESS_EXPIRY  = process.env.JWT_EXPIRES_IN || '8h';
const REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

/**
 * Sign an access token
 */
const signAccessToken = (payload) => {
  const jti = uuidv4();
  return jwt.sign(
    { ...payload, jti, type: 'access' },
    ACCESS_SECRET,
    { expiresIn: ACCESS_EXPIRY, algorithm: 'HS256' }
  );
};

/**
 * Sign a refresh token
 */
const signRefreshToken = (payload) => {
  const jti = uuidv4();
  return jwt.sign(
    { sub: payload.userId, jti, type: 'refresh' },
    REFRESH_SECRET,
    { expiresIn: REFRESH_EXPIRY, algorithm: 'HS256' }
  );
};

/**
 * Verify access token and check blacklist
 */
const verifyAccessToken = async (token) => {
  const decoded = jwt.verify(token, ACCESS_SECRET, { algorithms: ['HS256'] });
  if (decoded.type !== 'access') throw new Error('Invalid token type');

  const blacklisted = await isTokenBlacklisted(decoded.jti);
  if (blacklisted) throw new Error('Token has been revoked');

  return decoded;
};

/**
 * Verify refresh token
 */
const verifyRefreshToken = (token) => {
  const decoded = jwt.verify(token, REFRESH_SECRET, { algorithms: ['HS256'] });
  if (decoded.type !== 'refresh') throw new Error('Invalid token type');
  return decoded;
};

/**
 * Revoke a token (add JTI to blacklist)
 */
const revokeToken = async (token, secret = ACCESS_SECRET) => {
  try {
    const decoded = jwt.decode(token);
    if (decoded?.jti && decoded?.exp) {
      const ttl = decoded.exp - Math.floor(Date.now() / 1000);
      if (ttl > 0) {
        await blacklistToken(decoded.jti, ttl);
      }
    }
  } catch (err) {
    logger.warn('Token revocation warning:', err.message);
  }
};

/**
 * Issue a full token pair
 */
const issueTokenPair = (user) => {
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    companyId: user.company_id,
  };
  return {
    accessToken: signAccessToken(payload),
    refreshToken: signRefreshToken(payload),
  };
};

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  revokeToken,
  issueTokenPair,
};
