const winston = require('winston');
require('winston-daily-rotate-file');

const { combine, timestamp, printf, colorize, errors } = winston.format;

const logFormat = printf(({ level, message, timestamp, stack, ...meta }) => {
  let log = `${timestamp} [${level.toUpperCase()}] ${stack || message}`;
  if (Object.keys(meta).length) log += ` ${JSON.stringify(meta)}`;
  return log;
});

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    errors({ stack: true }),
    logFormat
  ),
  transports: [
    // Console
    new winston.transports.Console({
      format: combine(colorize(), timestamp({ format: 'HH:mm:ss' }), logFormat),
    }),
    // Daily rotating app log
    new winston.transports.DailyRotateFile({
      dirname: process.env.LOG_DIR || './logs',
      filename: 'vaultshare-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '50m',
      maxFiles: '30d',
      zippedArchive: true,
    }),
    // Separate error log
    new winston.transports.DailyRotateFile({
      dirname: process.env.LOG_DIR || './logs',
      filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      level: 'error',
      maxSize: '20m',
      maxFiles: '90d',
      zippedArchive: true,
    }),
  ],
  exceptionHandlers: [
    new winston.transports.File({
      dirname: process.env.LOG_DIR || './logs',
      filename: 'exceptions.log',
    }),
  ],
  rejectionHandlers: [
    new winston.transports.File({
      dirname: process.env.LOG_DIR || './logs',
      filename: 'rejections.log',
    }),
  ],
});

module.exports = logger;
