#!/bin/bash
# ================================================================
#  VaultShare — One-Click Install
#  Ubuntu 24 EC2 — No Docker, No AWS services
#
#  Usage:
#    bash install.sh
# ================================================================
set -e
RED='\033[0;31m';GREEN='\033[0;32m';YELLOW='\033[1;33m';CYAN='\033[0;36m';BOLD='\033[1m';NC='\033[0m'
info(){ echo -e "${CYAN}[INFO]${NC}  $1"; }
ok(){   echo -e "${GREEN}[ OK ]${NC}  $1"; }
warn(){ echo -e "${YELLOW}[WARN]${NC}  $1"; }
die(){  echo -e "${RED}[FAIL]${NC}  $1"; exit 1; }
section(){ echo -e "\n${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  $1\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"; }

[ "$EUID" -eq 0 ] && die "Run as ubuntu user, not root."

# Script lives inside the repo — APP_DIR is the repo root
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPLOAD_DIR="/var/www/vaultshare/uploads"
FRONTEND_DIR="/var/www/vaultshare/frontend"
LOG_DIR="/var/log/vaultshare"

# ── CONFIG ───────────────────────────────────────────────────────
section "VaultShare — One-Click Install"
echo -e "Answer 3 questions, everything else is automatic.\n"
read -rp "  MySQL password  (make one up): " DB_PASSWORD
[ -z "$DB_PASSWORD" ] && die "DB password required"
read -rp "  Redis password  (make one up): " REDIS_PASSWORD
[ -z "$REDIS_PASSWORD" ] && die "Redis password required"
PUBLIC_IP=$(curl -s --max-time 5 http://checkip.amazonaws.com 2>/dev/null || hostname -I | awk '{print $1}')
read -rp "  Server IP or domain [$PUBLIC_IP]: " USER_IP
[ -z "$USER_IP" ] && USER_IP="$PUBLIC_IP"
FRONTEND_URL="http://${USER_IP}"
JWT_SECRET=$(openssl rand -hex 32)
JWT_REFRESH_SECRET=$(openssl rand -hex 32)
SESSION_SECRET=$(openssl rand -hex 32)
echo ""; ok "Config ready. Installing...\n"

# ── STEP 1: Update system ─────────────────────────────────────────
section "STEP 1 — System Update"
sudo apt-get update -y -q
sudo apt-get install -y -q curl wget unzip git python3 ca-certificates
ok "System ready."

# ── STEP 2: Swap memory ───────────────────────────────────────────
section "STEP 2 — Swap Memory (prevents npm crashes)"
if ! swapon --show | grep -q /swapfile 2>/dev/null; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile
  sudo mkswap /swapfile && sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab > /dev/null
  ok "2GB swap created."
else
  ok "Swap already exists."
fi

# ── STEP 3: Node.js 20 ────────────────────────────────────────────
section "STEP 3 — Node.js 20"
if ! node --version 2>/dev/null | grep -q "v20"; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - > /dev/null 2>&1
  sudo apt-get install -y nodejs
fi
sudo npm install -g pm2 --silent
ok "Node.js $(node --version) + PM2 ready."

# ── STEP 4: MySQL 8 ───────────────────────────────────────────────
section "STEP 4 — MySQL 8.0"
if ! systemctl is-active --quiet mysql 2>/dev/null; then
  sudo apt-get install -y mysql-server
  sudo systemctl enable mysql && sudo systemctl start mysql
fi
sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root_${DB_PASSWORD}'; FLUSH PRIVILEGES;" 2>/dev/null || true
sudo mysql -uroot -p"root_${DB_PASSWORD}" -e "
  CREATE DATABASE IF NOT EXISTS vaultshare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER IF NOT EXISTS 'vaultshare_admin'@'localhost' IDENTIFIED BY '${DB_PASSWORD}';
  GRANT ALL PRIVILEGES ON vaultshare.* TO 'vaultshare_admin'@'localhost';
  FLUSH PRIVILEGES;" 2>/dev/null
ok "MySQL ready."

# ── STEP 5: Redis 7 ───────────────────────────────────────────────
section "STEP 5 — Redis 7"
if ! systemctl is-active --quiet redis-server 2>/dev/null; then
  sudo apt-get install -y redis-server
fi
sudo bash -c "cat > /etc/redis/redis.conf << REDEOF
bind 127.0.0.1
port 6379
requirepass ${REDIS_PASSWORD}
appendonly yes
dir /var/lib/redis
loglevel notice
logfile /var/log/redis/redis-server.log
maxmemory 256mb
maxmemory-policy allkeys-lru
REDEOF"
sudo systemctl enable redis-server && sudo systemctl restart redis-server
ok "Redis ready."

# ── STEP 6: Nginx ─────────────────────────────────────────────────
section "STEP 6 — Nginx"
sudo apt-get install -y nginx
sudo systemctl enable nginx && sudo systemctl start nginx
ok "Nginx ready."

# ── STEP 7: Mailpit ───────────────────────────────────────────────
section "STEP 7 — Mailpit (Local Email)"
if ! command -v mailpit &>/dev/null; then
  sudo bash -c "$(curl -sL https://raw.githubusercontent.com/axllent/mailpit/develop/install.sh)" > /dev/null 2>&1
fi
sudo bash -c 'cat > /etc/systemd/system/mailpit.service << MPEOF
[Unit]
Description=Mailpit
After=network.target
[Service]
ExecStart=/usr/local/bin/mailpit --smtp 127.0.0.1:1025 --listen 0.0.0.0:8025
Restart=always
User=nobody
Group=nogroup
[Install]
WantedBy=multi-user.target
MPEOF'
sudo systemctl daemon-reload && sudo systemctl enable mailpit && sudo systemctl restart mailpit
ok "Mailpit ready — email UI: http://${USER_IP}:8025"

# ── STEP 8: Create folders ────────────────────────────────────────
section "STEP 8 — Create Folders"
sudo mkdir -p "$UPLOAD_DIR" "$LOG_DIR" "$FRONTEND_DIR"
sudo chown -R "$USER:$USER" "$UPLOAD_DIR" "$LOG_DIR" "$FRONTEND_DIR"
mkdir -p "$APP_DIR/backend/logs"
ok "Folders ready."

# ── STEP 9: Write .env ────────────────────────────────────────────
section "STEP 9 — Write Config"
cat > "$APP_DIR/backend/.env" << ENVEOF
NODE_ENV=production
PORT=5000
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=vaultshare
DB_USER=vaultshare_admin
DB_PASSWORD=${DB_PASSWORD}
DB_SSL=false
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_PASSWORD=${REDIS_PASSWORD}
JWT_SECRET=${JWT_SECRET}
JWT_REFRESH_SECRET=${JWT_REFRESH_SECRET}
JWT_EXPIRES_IN=8h
JWT_REFRESH_EXPIRES_IN=7d
LOCAL_STORAGE_PATH=${UPLOAD_DIR}
AWS_REGION=local
AWS_ACCESS_KEY_ID=local
AWS_SECRET_ACCESS_KEY=local
S3_BUCKET_NAME=local
S3_PRESIGNED_URL_EXPIRY=3600
SMTP_HOST=127.0.0.1
SMTP_PORT=1025
SES_FROM_EMAIL=noreply@vaultshare.local
SES_FROM_NAME=VaultShare
ADMIN_EMAIL=admin@vaultshare.local
BCRYPT_ROUNDS=12
TOTP_ISSUER=VaultShare
SESSION_SECRET=${SESSION_SECRET}
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100
AUTH_RATE_LIMIT_MAX=10
FRONTEND_URL=${FRONTEND_URL}
MAX_FILE_SIZE_MB=500
ALLOWED_MIME_TYPES=application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,image/jpeg,image/png,image/gif,application/zip,text/plain,text/csv
LOG_LEVEL=info
LOG_DIR=${LOG_DIR}
ENVEOF
ok ".env written."

# ── STEP 10: Apply database schema ────────────────────────────────
section "STEP 10 — Apply Database Schema"
mysql -u vaultshare_admin -p"${DB_PASSWORD}" -e "DROP DATABASE IF EXISTS vaultshare; CREATE DATABASE vaultshare CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null
mysql -u vaultshare_admin -p"${DB_PASSWORD}" vaultshare < "$APP_DIR/backend/src/config/schema.sql" 2>/dev/null
ok "Database schema applied."

# ── STEP 11: Install backend dependencies ─────────────────────────
section "STEP 11 — Install Backend Dependencies"
cd "$APP_DIR/backend"
npm install --no-audit --no-fund
ok "Backend dependencies installed."

# ── STEP 12: Build frontend ───────────────────────────────────────
section "STEP 12 — Build Frontend"
cd "$APP_DIR/frontend"
npm install --no-audit --no-fund --legacy-peer-deps
NODE_OPTIONS="--max-old-space-size=512" REACT_APP_API_URL="${FRONTEND_URL}/api" npm run build
sudo cp -r build/* "$FRONTEND_DIR/"
ok "Frontend built and deployed."

# ── STEP 13: Configure Nginx ──────────────────────────────────────
section "STEP 13 — Configure Nginx"
sudo bash -c "cat > /etc/nginx/sites-available/vaultshare << NGINXEOF
server {
    listen 80;
    server_name ${USER_IP} _;
    client_max_body_size 512M;
    add_header X-Frame-Options \"DENY\" always;
    add_header X-Content-Type-Options \"nosniff\" always;
    location / {
        root ${FRONTEND_DIR};
        index index.html;
        try_files \\\$uri \\\$uri/ /index.html;
    }
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host \\\$host;
        proxy_set_header X-Real-IP \\\$remote_addr;
        proxy_set_header X-Forwarded-For \\\$proxy_add_x_forwarded_for;
        proxy_read_timeout 120s;
    }
    access_log /var/log/nginx/vaultshare_access.log;
    error_log  /var/log/nginx/vaultshare_error.log;
}
NGINXEOF"
sudo ln -sf /etc/nginx/sites-available/vaultshare /etc/nginx/sites-enabled/vaultshare
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
ok "Nginx configured."

# ── STEP 14: Start backend with PM2 ──────────────────────────────
section "STEP 14 — Start Backend"
cd "$APP_DIR/backend"
pm2 delete vaultshare-backend 2>/dev/null || true
pm2 start src/server.js --name vaultshare-backend --time --restart-delay=3000 --max-restarts=10
pm2 save
PM2_CMD=$(pm2 startup systemd -u "$USER" --hp "$HOME" 2>/dev/null | grep "sudo env" || true)
[ -n "$PM2_CMD" ] && eval "$PM2_CMD" || true
ok "Backend started with PM2."

# ── STEP 15: Health check ─────────────────────────────────────────
section "STEP 15 — Health Check"
sleep 8
sudo systemctl is-active --quiet mysql        && ok "MySQL     ✅ running" || warn "MySQL     ❌ check: sudo systemctl status mysql"
sudo systemctl is-active --quiet redis-server && ok "Redis     ✅ running" || warn "Redis     ❌ check: sudo systemctl status redis-server"
sudo systemctl is-active --quiet nginx        && ok "Nginx     ✅ running" || warn "Nginx     ❌ check: sudo systemctl status nginx"
sudo systemctl is-active --quiet mailpit      && ok "Mailpit   ✅ running" || warn "Mailpit   ❌ check: sudo systemctl status mailpit"
HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:5000/api/health 2>/dev/null || echo "000")
[ "$HTTP" = "200" ] && ok "Backend   ✅ healthy" || warn "Backend   ❌ HTTP $HTTP — run: pm2 logs vaultshare-backend"
HTTP2=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1/ 2>/dev/null || echo "000")
[ "$HTTP2" = "200" ] && ok "Frontend  ✅ serving" || warn "Frontend  ❌ HTTP $HTTP2 — check nginx logs"

# ── DONE ─────────────────────────────────────────────────────────
section "INSTALL COMPLETE ✅"
echo -e "${GREEN}${BOLD}VaultShare is running!${NC}\n"
echo -e "  🌐  App:         ${BOLD}${FRONTEND_URL}${NC}"
echo -e "  📧  Email inbox: ${BOLD}http://${USER_IP}:8025${NC}  ← see all system emails here"
echo ""
echo -e "${YELLOW}${BOLD}Admin login:${NC}"
echo -e "  Email:    admin@vaultshare.io"
echo -e "  Password: Admin@123456"
echo -e "  ${RED}⚠  Change password immediately after first login!${NC}"
echo ""
echo -e "${YELLOW}${BOLD}Useful commands:${NC}"
echo -e "  View logs:   ${CYAN}pm2 logs vaultshare-backend${NC}"
echo -e "  Restart:     ${CYAN}pm2 restart vaultshare-backend${NC}"
echo -e "  Status:      ${CYAN}pm2 status${NC}"
echo ""
echo -e "${YELLOW}${BOLD}EC2 Security Group — open ports: 22, 80, 8025${NC}"
